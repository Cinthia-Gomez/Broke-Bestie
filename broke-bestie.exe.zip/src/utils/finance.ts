import { FinancialProfile, FinancialHealthMetrics, HealthStatus } from '../types';

/**
 * Convert integer cents to a formatted currency string ($X.XX)
 */
export function centsToCurrency(cents: number): string {
  const isNegative = cents < 0;
  const absCents = Math.abs(cents);
  const dollars = Math.floor(absCents / 100);
  const remainderCents = absCents % 100;
  const formatted = `${dollars.toLocaleString('en-US')}.${remainderCents.toString().padStart(2, '0')}`;
  return isNegative ? `-$${formatted}` : `$${formatted}`;
}

/**
 * Safely parse a user-entered amount string into integer cents
 */
export function parseToCents(amount: string | number): number {
  if (typeof amount === 'number') {
    return Math.round(amount * 100);
  }
  const clean = amount.replace(/[^0-9.-]/g, '');
  const parsed = parseFloat(clean);
  if (isNaN(parsed)) return 0;
  return Math.round(parsed * 100);
}

/**
 * Calculate the number of days between two dates (or today and target date)
 */
export function getDaysRemaining(targetDateStr: string): number {
  const now = new Date();
  // Strip time for clean day diff
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const [year, month, day] = targetDateStr.split('-').map(Number);
  const target = new Date(year, month - 1, day);

  const diffMs = target.getTime() - today.getTime();
  const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  return Math.max(1, diffDays); // Minimum 1 day to prevent division by zero
}

/**
 * Core Financial Calculation Engine (Integer cents)
 */
export function calculateHealthMetrics(profile: FinancialProfile): FinancialHealthMetrics {
  const totalFundsCents = profile.bankBalanceCents + profile.cashBalanceCents;

  // Unpaid bills reserve
  const unpaidBillsCents = profile.bills
    .filter((b) => !b.isPaid)
    .reduce((acc, b) => acc + b.amountCents, 0);

  // Remaining essentials needed for this pay period
  const remainingEssentialsCents = profile.essentials.reduce((acc, cat) => {
    const unspent = Math.max(0, cat.budgetedCents - cat.spentCents);
    return acc + unspent;
  }, 0);

  // Reserved money required to survive until next check
  const reservedFundsCents = unpaidBillsCents + remainingEssentialsCents;

  // Safe-to-spend discretionary buffer
  const safeToSpendCents = totalFundsCents - reservedFundsCents;

  // Days until payday
  const daysRemaining = getDaysRemaining(profile.nextPaydayDate);

  // Calculate total cycle length in days (between lastPayday and nextPayday, or default 14)
  let totalCycleDays = 14;
  if (profile.lastPaydayDate) {
    const [ly, lm, ld] = profile.lastPaydayDate.split('-').map(Number);
    const [ny, nm, nd] = profile.nextPaydayDate.split('-').map(Number);
    const lastDate = new Date(ly, lm - 1, ld);
    const nextDate = new Date(ny, nm - 1, nd);
    const cycleMs = nextDate.getTime() - lastDate.getTime();
    const cycleDays = Math.round(cycleMs / (1000 * 60 * 60 * 24));
    if (cycleDays > 0) totalCycleDays = cycleDays;
  }
  const cycleDayNumber = Math.max(1, Math.min(totalCycleDays, totalCycleDays - daysRemaining + 1));

  // Recommended daily spending allowance
  const dailyAllowanceCents = safeToSpendCents > 0
    ? Math.floor(safeToSpendCents / daysRemaining)
    : 0;

  // Shortfall when reserved bills/essentials exceed available funds
  const shortfallCents = safeToSpendCents < 0 ? Math.abs(safeToSpendCents) : 0;

  // Risk status:
  // RED: Safe to spend is negative (shortfall exists) OR bank & cash are completely empty
  // YELLOW: Safe to spend is less than 20% of total funds OR daily allowance is under $10 (1000 cents)
  // GREEN: On track
  let healthStatus: HealthStatus = 'green';
  let healthScorePercent = 100;

  if (safeToSpendCents < 0 || totalFundsCents <= 0) {
    healthStatus = 'red';
    // When in deficit, score is low (0 - 30%)
    const deficitRatio = totalFundsCents > 0 ? (safeToSpendCents / reservedFundsCents) : -1;
    healthScorePercent = Math.max(5, Math.min(30, Math.round(30 + deficitRatio * 25)));
  } else if (
    safeToSpendCents < totalFundsCents * 0.2 ||
    dailyAllowanceCents < 1000 ||
    safeToSpendCents < 5000
  ) {
    healthStatus = 'yellow';
    healthScorePercent = Math.max(35, Math.min(69, Math.round(35 + (safeToSpendCents / (totalFundsCents || 1)) * 34)));
  } else {
    healthStatus = 'green';
    healthScorePercent = Math.min(100, Math.max(70, Math.round(70 + Math.min(30, (dailyAllowanceCents / 4000) * 30))));
  }

  return {
    totalFundsCents,
    bankBalanceCents: profile.bankBalanceCents,
    cashBalanceCents: profile.cashBalanceCents,
    unpaidBillsCents,
    remainingEssentialsCents,
    reservedFundsCents,
    safeToSpendCents,
    daysRemaining,
    totalCycleDays,
    cycleDayNumber,
    dailyAllowanceCents,
    healthStatus,
    healthScorePercent,
    shortfallCents,
  };
}

/**
 * Get date string offset from today in YYYY-MM-DD
 */
export function getOffsetDateString(daysOffset: number): string {
  const d = new Date();
  d.setDate(d.getDate() + daysOffset);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Demo financial profile for hackathon evaluators
 */
export function getDemoFinancialProfile(): FinancialProfile {
  return {
    bankBalanceCents: 68500, // $685.00
    cashBalanceCents: 6500,  // $65.00
    expectedPaycheckCents: 165000, // $1,650.00
    payFrequency: 'biweekly',
    nextPaydayDate: getOffsetDateString(6), // 6 days until payday
    lastPaydayDate: getOffsetDateString(-8), // 8 days ago
    bills: [
      {
        id: 'bill-1',
        name: 'Electric & Power Bill',
        amountCents: 6800, // $68.00
        dueDate: getOffsetDateString(2),
        category: 'utilities',
        isPaid: false,
      },
      {
        id: 'bill-2',
        name: 'Mobile Phone Plan',
        amountCents: 5200, // $52.00
        dueDate: getOffsetDateString(4),
        category: 'phone',
        isPaid: false,
      },
      {
        id: 'bill-3',
        name: 'Streaming Service',
        amountCents: 1599, // $15.99
        dueDate: getOffsetDateString(-2),
        category: 'subscription',
        isPaid: true,
      },
    ],
    essentials: [
      {
        id: 'ess-1',
        name: 'Groceries & Meal Prep',
        budgetedCents: 14000, // $140.00
        spentCents: 6500,     // $65.00 spent
        iconName: 'ShoppingBag',
      },
      {
        id: 'ess-2',
        name: 'Gas & Transportation',
        budgetedCents: 6000,  // $60.00
        spentCents: 2500,     // $25.00 spent
        iconName: 'Car',
      },
      {
        id: 'ess-3',
        name: 'Pharmacy & Wellness',
        budgetedCents: 3500,  // $35.00
        spentCents: 1000,     // $10.00 spent
        iconName: 'HeartPulse',
      },
    ],
    transactions: [
      {
        id: 'tx-1',
        description: 'Supermarket Groceries',
        amountCents: 4500,
        type: 'expense',
        paymentMethod: 'bank',
        date: new Date(Date.now() - 86400000 * 2).toISOString(),
        category: 'Food',
        essentialCategoryId: 'ess-1',
      },
      {
        id: 'tx-2',
        description: 'Gas Station Refill',
        amountCents: 2500,
        type: 'expense',
        paymentMethod: 'bank',
        date: new Date(Date.now() - 86400000).toISOString(),
        category: 'Transport',
        essentialCategoryId: 'ess-2',
      },
      {
        id: 'tx-3',
        description: 'ATM Cash Withdrawal',
        amountCents: 5000,
        type: 'transfer_to_cash',
        paymentMethod: 'bank',
        date: new Date(Date.now() - 86400000 * 3).toISOString(),
        category: 'Transfer',
      },
      {
        id: 'tx-4',
        description: 'Coffee Shop Matcha Latte',
        amountCents: 650,
        type: 'expense',
        paymentMethod: 'cash',
        date: new Date(Date.now() - 3600000 * 4).toISOString(),
        category: 'Treat',
        isDeluluPurchase: false,
      },
    ],
    savedItems: [
      {
        id: 'wish-1',
        name: 'Cute Platform Sneakers',
        amountCents: 7800,
        savedDate: new Date(Date.now() - 86400000).toISOString(),
      },
      {
        id: 'wish-2',
        name: 'Mechanical Gaming Keycaps',
        amountCents: 4200,
        savedDate: new Date(Date.now() - 86400000 * 3).toISOString(),
      },
    ],
  };
}

/**
 * Initial empty financial profile for new users
 */
export function getInitialFinancialProfile(): FinancialProfile {
  return {
    bankBalanceCents: 0,
    cashBalanceCents: 0,
    expectedPaycheckCents: 0,
    payFrequency: 'biweekly',
    nextPaydayDate: getOffsetDateString(7),
    lastPaydayDate: getOffsetDateString(-7),
    bills: [],
    essentials: [
      {
        id: 'ess-1',
        name: 'Groceries & Food',
        budgetedCents: 10000,
        spentCents: 0,
        iconName: 'ShoppingBag',
      },
      {
        id: 'ess-2',
        name: 'Gas & Transportation',
        budgetedCents: 4000,
        spentCents: 0,
        iconName: 'Car',
      },
      {
        id: 'ess-3',
        name: 'Prescriptions & Care',
        budgetedCents: 2500,
        spentCents: 0,
        iconName: 'HeartPulse',
      },
    ],
    transactions: [],
    savedItems: [],
  };
}
