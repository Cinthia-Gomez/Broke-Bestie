import { AppMode } from '../types';

export interface ModeTheme {
  name: string;
  tagline: string;
  bgCanvas: string;
  cardBg: string;
  cardBorder: string;
  cardShadow: string;
  windowHeaderBg: string;
  windowHeaderText: string;
  primaryButton: string;
  secondaryButton: string;
  accentText: string;
  badgeBg: string;
  badgeBorder: string;
  statBoxBg: string;
  statBoxBorder: string;
  inputBg: string;
  inputBorder: string;
  mascotImage: string;
  mascotName: string;
}

export const THEMES: Record<AppMode, ModeTheme> = {
  bestie: {
    name: 'Bestie Mode 💗',
    tagline: 'Budgeting, but make it cute.',
    bgCanvas: 'bg-[#FFF4E8] text-[#4A1525]',
    cardBg: 'bg-white/95 backdrop-blur-sm',
    cardBorder: 'border-2 border-[#A64D79]/30',
    cardShadow: 'shadow-[4px_4px_0px_0px_rgba(166,77,121,0.25)]',
    windowHeaderBg: 'bg-gradient-to-r from-[#F6D5E3] via-[#E8DDF5] to-[#F6D5E3] border-b-2 border-[#A64D79]/30',
    windowHeaderText: 'text-[#A64D79] font-bold',
    primaryButton: 'bg-[#A64D79] hover:bg-[#8e3f65] text-white font-bold border-2 border-[#541c38] shadow-[3px_3px_0px_0px_#541c38] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all',
    secondaryButton: 'bg-[#F6D5E3] hover:bg-[#edd0dd] text-[#A64D79] font-bold border-2 border-[#A64D79]/40 shadow-[2px_2px_0px_0px_rgba(166,77,121,0.3)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all',
    accentText: 'text-[#D94B65]',
    badgeBg: 'bg-[#F6D5E3]/60 text-[#A64D79]',
    badgeBorder: 'border border-[#A64D79]/30',
    statBoxBg: 'bg-[#FFF9F3]',
    statBoxBorder: 'border border-[#A64D79]/20',
    inputBg: 'bg-white',
    inputBorder: 'border-2 border-[#A64D79]/30 focus:border-[#A64D79] focus:ring-2 focus:ring-[#F6D5E3]',
    mascotImage: '/src/assets/images/bestie_mascot_pixel_1792259485056.jpg',
    mascotName: 'Bestie Bot 💖',
  },
  classic: {
    name: 'Classic Mode 🎮',
    tagline: 'Beat the budget. Reach payday.',
    bgCanvas: 'bg-[#0E1726] text-[#F8FAFC]',
    cardBg: 'bg-[#18243A]/90 backdrop-blur-sm',
    cardBorder: 'border-2 border-[#4A90E2]/40',
    cardShadow: 'shadow-[4px_4px_0px_0px_rgba(74,144,226,0.3)]',
    windowHeaderBg: 'bg-gradient-to-r from-[#18243A] via-[#20324E] to-[#18243A] border-b-2 border-[#4A90E2]/40',
    windowHeaderText: 'text-[#8DD9B5] font-bold tracking-wide',
    primaryButton: 'bg-[#4A90E2] hover:bg-[#3b7dc7] text-white font-bold border-2 border-[#18243A] shadow-[3px_3px_0px_0px_#18243A] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all',
    secondaryButton: 'bg-[#20324E] hover:bg-[#283e61] text-[#8DD9B5] font-bold border-2 border-[#4A90E2]/40 shadow-[2px_2px_0px_0px_rgba(74,144,226,0.3)] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all',
    accentText: 'text-[#8DD9B5]',
    badgeBg: 'bg-[#20324E] text-[#8DD9B5]',
    badgeBorder: 'border border-[#4A90E2]/40',
    statBoxBg: 'bg-[#131D2E]',
    statBoxBorder: 'border border-[#4A90E2]/30',
    inputBg: 'bg-[#131D2E]',
    inputBorder: 'border-2 border-[#4A90E2]/40 text-white focus:border-[#8DD9B5] focus:ring-2 focus:ring-[#4A90E2]/20',
    mascotImage: '/src/assets/images/arcade_bot_mascot_1792259485311.jpg',
    mascotName: 'SURVIVOR-M08 🤖',
  },
};
