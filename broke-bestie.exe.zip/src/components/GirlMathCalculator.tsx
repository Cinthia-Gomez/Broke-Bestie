import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import { THEMES } from '../utils/theme';
import { centsToCurrency, parseToCents } from '../utils/finance';
import { Sparkles, HelpCircle, ArrowRight, Lightbulb, Calculator, Smile, CheckCircle2 } from 'lucide-react';
import { sound } from '../utils/audio';

interface MythScenario {
  id: string;
  titleBestie: string;
  titleClassic: string;
  girlMathQuote: string;
  realMathQuote: string;
  classicMyth: string;
  classicFact: string;
  defaultAmount: string;
  details: string;
}

const PRESET_SCENARIOS: MythScenario[] = [
  {
    id: 'cash_is_free',
    titleBestie: 'Scenario A: "Cash Is Free Money" 💵',
    titleClassic: 'Case 01: Physical Cash Neutrality Fallacy',
    girlMathQuote: 'If I paid in cash, my bank card balance didn’t change. So technically it was completely free! ✨',
    realMathQuote: 'Bestie, you still spent that cash! Your total available money and survival allowance decreased.',
    classicMyth: 'Spending physical banknotes does not register on debit statements, creating a cost-neutral transaction.',
    classicFact: 'All cash originates from earned income or ATM bank withdrawals. Every dollar spent directly reduces overall liquidity.',
    defaultAmount: '25.00',
    details: 'Withdrawing $50 from an ATM is a transfer between pockets. But handing that $25 to a cashier permanently removes it from your net worth.',
  },
  {
    id: 'shopping_sales',
    titleBestie: 'Scenario B: "Shopping Sales = Making Profit" 🛍️',
    titleClassic: 'Case 02: Discount Profitability Paradox',
    girlMathQuote: 'It was originally $100, but I only paid $60! I basically made a $40 profit today! 🤑',
    realMathQuote: 'You didn’t make $40, you spent $60! You paid $40 less than retail, but $60 left your wallet forever.',
    classicMyth: 'Purchasing an item at a 40% markdown generates positive capital equivalent to the discount.',
    classicFact: 'A discount only attenuates capital outflow. The transaction still constitutes a net loss of $60 in liquid reserves.',
    defaultAmount: '60.00',
    details: 'You only save money if you were already 100% committed to buying that exact item at full price.',
  },
  {
    id: 'returns_as_income',
    titleBestie: 'Scenario C: "Store Returns Are Free Paychecks" 👗',
    titleClassic: 'Case 03: Refund Yield Misconception',
    girlMathQuote: 'I returned a $50 dress to the store. That is literally $50 of brand new free income! Free coffee all week! ☕',
    realMathQuote: 'You only recovered money you had already spent before. Your wallet is just back at square one, not richer.',
    classicMyth: 'Product returns generate surplus discretionary yield.',
    classicFact: 'A refund is a capital restoration returning funds to prior baseline status. It does not generate surplus yield.',
    defaultAmount: '50.00',
    details: 'Psychologically treating a refund like a bonus often triggers a second round of impulse shopping!',
  },
  {
    id: 'girl_dinner',
    titleBestie: 'Scenario D: "Girl Dinner / Food At Home Is Free" 🧀',
    titleClassic: 'Case 04: Pantry Provision Sunk Cost',
    girlMathQuote: 'I already bought groceries last Sunday, so tonight’s charcuterie dinner is 100% free! 🥖',
    realMathQuote: 'Using groceries you already bought is amazing because it prevents a $30 DoorDash delivery charge tonight!',
    classicMyth: 'Prepared household food stores represent zero-cost consumption.',
    classicFact: 'Consuming pre-stocked inventory leverages previously allocated grocery reserves and prevents incremental restaurant outflow.',
    defaultAmount: '30.00',
    details: 'Eating food in the fridge is one of the highest leverage ways to protect your safe-to-spend allowance before payday.',
  },
];

export const GirlMathCalculator: React.FC = () => {
  const { mode, unlockAchievement } = useGame();
  const theme = THEMES[mode];

  const [activeScenarioId, setActiveScenarioId] = useState<string>('cash_is_free');
  const [customOriginalPrice, setCustomOriginalPrice] = useState<string>('120.00');
  const [customPaidPrice, setCustomPaidPrice] = useState<string>('75.00');

  const selectedScenario =
    PRESET_SCENARIOS.find((s) => s.id === activeScenarioId) || PRESET_SCENARIOS[0];

  const handleSelectScenario = (id: string) => {
    setActiveScenarioId(id);
    sound.playGirlMathSparkle();
    unlockAchievement('math_scholar');
  };

  const origCents = parseToCents(customOriginalPrice);
  const paidCents = parseToCents(customPaidPrice);
  const discountSavedCents = Math.max(0, origCents - paidCents);

  return (
    <div className="space-y-6">
      {/* Title Header */}
      <div
        className={`p-5 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} relative overflow-hidden`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">{mode === 'bestie' ? '🎀' : '📊'}</span>
              <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight">
                {mode === 'bestie' ? 'GIRL MATH.EXE 💗' : 'MONEY MYTHS VS. MONEY FACTS 📊'}
              </h2>
            </div>
            <p className="text-xs opacity-75 mt-1 max-w-xl">
              {mode === 'bestie'
                ? 'The hilarious logic we tell ourselves to justify our spending, paired with the real, honest financial arithmetic!'
                : 'Deconstructing common cognitive spending fallacies with quantitative financial reality checks.'}
            </p>
          </div>

          <div
            className={`px-3 py-1.5 rounded-lg border text-xs font-bold font-pixel tracking-wider ${
              mode === 'bestie'
                ? 'bg-[#F6D5E3] text-[#A64D79] border-[#A64D79]/30'
                : 'bg-[#20324E] text-[#8DD9B5] border-[#4A90E2]/40'
            }`}
          >
            {mode === 'bestie' ? '✨ SATIRE ENGINE: ACTIVATED' : 'ANALYSIS MODE: ACTIVE'}
          </div>
        </div>
      </div>

      {/* Preset Scenario Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {PRESET_SCENARIOS.map((scen) => {
          const isSelected = scen.id === activeScenarioId;
          const title = mode === 'bestie' ? scen.titleBestie : scen.titleClassic;
          return (
            <button
              key={scen.id}
              onClick={() => handleSelectScenario(scen.id)}
              className={`p-3 rounded-xl border-2 text-left cursor-pointer transition-all ${
                isSelected
                  ? mode === 'bestie'
                    ? 'bg-[#F6D5E3] border-[#A64D79] text-[#A64D79] shadow-[3px_3px_0px_#A64D79] font-bold'
                    : 'bg-[#20324E] border-[#4A90E2] text-[#8DD9B5] shadow-[3px_3px_0px_#4A90E2] font-bold'
                  : `${theme.cardBg} ${theme.cardBorder} opacity-75 hover:opacity-100`
              }`}
            >
              <span className="text-xs line-clamp-2">{title}</span>
            </button>
          );
        })}
      </div>

      {/* Active Scenario Showcase Card */}
      <div
        className={`p-6 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} space-y-6`}
      >
        <div className="flex items-center justify-between border-b border-inherit pb-3">
          <h3 className="font-black text-base uppercase tracking-tight">
            {mode === 'bestie' ? selectedScenario.titleBestie : selectedScenario.titleClassic}
          </h3>
          <span className="text-xs opacity-60">Interactive Myth Breakdown</span>
        </div>

        {/* 2-Side Comparison: Myth vs Reality */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Fun / Myth Side */}
          <div
            className={`p-5 rounded-2xl border-2 space-y-3 relative overflow-hidden ${
              mode === 'bestie'
                ? 'bg-gradient-to-br from-[#FFF4E8] to-[#F6D5E3] border-[#A64D79]/40'
                : 'bg-gradient-to-br from-[#18243A] to-[#20324E] border-[#4A90E2]/40'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-wider flex items-center gap-1.5 text-pink-600 dark:text-pink-400">
                <Sparkles className="w-4 h-4" />
                <span>{mode === 'bestie' ? 'GIRL MATH SAYS: 💅' : 'THE COGNITIVE MYTH: 💭'}</span>
              </span>
              <span className="text-xl">{mode === 'bestie' ? '🎀' : '👾'}</span>
            </div>

            <blockquote className="text-sm sm:text-base font-bold italic leading-relaxed">
              "{mode === 'bestie' ? selectedScenario.girlMathQuote : selectedScenario.classicMyth}"
            </blockquote>

            <div className="text-[11px] opacity-75 bg-white/60 dark:bg-black/30 p-2.5 rounded-lg">
              <span className="font-bold">The Vibe: </span>
              {mode === 'bestie'
                ? 'Sounds amazing in our heads and justifies a retail treat!'
                : 'Flawed intuitive heuristic disregarding total liquidity conservation.'}
            </div>
          </div>

          {/* Real Math Side */}
          <div
            className={`p-5 rounded-2xl border-2 space-y-3 relative overflow-hidden ${
              mode === 'bestie'
                ? 'bg-emerald-50/70 border-emerald-400 text-emerald-950 dark:text-emerald-100'
                : 'bg-[#131D2E] border-emerald-500/40 text-emerald-300'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-wider flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                <span>{mode === 'bestie' ? 'REAL FINANCIAL MATH: 🧠' : 'MATHEMATICAL REALITY: 📐'}</span>
              </span>
              <span className="text-xl">📊</span>
            </div>

            <p className="text-sm sm:text-base font-bold leading-relaxed">
              "{mode === 'bestie' ? selectedScenario.realMathQuote : selectedScenario.classicFact}"
            </p>

            <div className="text-[11px] opacity-80 bg-white/80 dark:bg-black/40 p-2.5 rounded-lg">
              <span className="font-bold">Survival takeaway: </span>
              {selectedScenario.details}
            </div>
          </div>
        </div>

        {/* Disclaimer banner */}
        <div
          className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
            mode === 'bestie'
              ? 'bg-[#FFF9F3] border-[#A64D79]/20 text-[#541c38]'
              : 'bg-[#18243A] border-[#4A90E2]/30 text-slate-300'
          }`}
        >
          <HelpCircle className="w-4 h-4 text-amber-500 shrink-0" />
          <p className="text-[11px]">
            <span className="font-bold">Friendly reminder: </span>
            {mode === 'bestie'
              ? 'Girl Math is 100% comedy for laughs with the besties! Broke Bestie’s actual wallet health meter always calculates real, cold, hard arithmetic.'
              : 'Heuristic mental accounting serves psychological rationalization, whereas survival balance tracks objective ledger invariants.'}
          </p>
        </div>
      </div>

      {/* Custom Sale / Myth Calculator Simulator */}
      <div
        className={`p-5 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} space-y-4`}
      >
        <div className="flex items-center gap-2">
          <Calculator className="w-4 h-4 text-purple-500" />
          <h3 className="font-black text-sm uppercase tracking-tight">
            {mode === 'bestie' ? 'Interactive Sale Myth Solver 🏷️' : 'Discount Outflow Matrix 🧮'}
          </h3>
        </div>

        <p className="text-xs opacity-75">
          Plug in any item on sale to compare what Girl Math thinks you "made" versus what actually left your bank account.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold mb-1 opacity-80">
              Original Retail Price ($)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-xs opacity-50 font-bold">$</span>
              <input
                type="number"
                step="0.01"
                value={customOriginalPrice}
                onChange={(e) => setCustomOriginalPrice(e.target.value)}
                className={`w-full pl-7 pr-3 py-2 rounded-lg text-sm font-mono ${theme.inputBg} ${theme.inputBorder}`}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold mb-1 opacity-80">
              Discounted Price You Paid ($)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-xs opacity-50 font-bold">$</span>
              <input
                type="number"
                step="0.01"
                value={customPaidPrice}
                onChange={(e) => setCustomPaidPrice(e.target.value)}
                className={`w-full pl-7 pr-3 py-2 rounded-lg text-sm font-mono ${theme.inputBg} ${theme.inputBorder}`}
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
          <div className="p-3 bg-pink-50 dark:bg-pink-950/40 border border-pink-300 dark:border-pink-800 rounded-xl">
            <span className="font-bold text-pink-700 dark:text-pink-300 block mb-0.5">
              {mode === 'bestie' ? '💅 Girl Math Profit' : 'Perceived Discount Yield'}
            </span>
            <span className="font-mono text-xl font-black text-pink-600 dark:text-pink-400">
              +{centsToCurrency(discountSavedCents)}
            </span>
            <p className="text-[11px] opacity-75 mt-0.5">"I literally made this money by shopping today!"</p>
          </div>

          <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-300 dark:border-blue-800 rounded-xl">
            <span className="font-bold text-blue-700 dark:text-blue-300 block mb-0.5">
              {mode === 'bestie' ? '🧠 Actual Wallet Outflow' : 'Actual Net Cash Drain'}
            </span>
            <span className="font-mono text-xl font-black text-blue-600 dark:text-blue-400">
              -{centsToCurrency(paidCents)}
            </span>
            <p className="text-[11px] opacity-75 mt-0.5">Your total bank account decreased by this amount.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
