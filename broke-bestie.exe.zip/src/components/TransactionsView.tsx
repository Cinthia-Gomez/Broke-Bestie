import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import { THEMES } from '../utils/theme';
import { centsToCurrency, parseToCents } from '../utils/finance';
import { PaymentMethod, TransactionType } from '../types';
import {
  CreditCard,
  Banknote,
  ArrowRightLeft,
  PlusCircle,
  MinusCircle,
  Trash2,
  Filter,
  CheckCircle,
  AlertCircle,
  ArrowDownLeft,
  ArrowUpRight,
  Sparkles,
} from 'lucide-react';

export const TransactionsView: React.FC<{ initialType?: 'expense' | 'income' | 'transfer' }> = ({
  initialType = 'expense',
}) => {
  const { mode, profile, metrics, addTransaction, deleteTransaction } = useGame();
  const theme = THEMES[mode];

  // Action form state
  const [actionTab, setActionTab] = useState<'expense' | 'transfer' | 'income'>(initialType);
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bank');
  const [transferDirection, setTransferDirection] = useState<'to_cash' | 'to_bank'>('to_cash');
  const [essentialCategory, setEssentialCategory] = useState<string>('');
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  // Filter history
  const [historyFilter, setHistoryFilter] = useState<'all' | 'expense' | 'transfer' | 'income'>('all');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSuccess(null);

    const amountCents = parseToCents(amount);
    if (amountCents <= 0) {
      setFormError('Please enter a valid amount greater than $0.00');
      return;
    }

    if (actionTab === 'transfer') {
      const type: TransactionType =
        transferDirection === 'to_cash' ? 'transfer_to_cash' : 'transfer_to_bank';
      const desc =
        transferDirection === 'to_cash' ? 'ATM Cash Withdrawal' : 'Cash Deposit to Bank';

      const res = addTransaction({
        description: desc,
        amountCents,
        type,
        paymentMethod: transferDirection === 'to_cash' ? 'bank' : 'cash',
        date: new Date().toISOString(),
        category: 'Transfer',
      });

      if (!res.success) {
        setFormError(res.error || 'Failed to process transfer');
        return;
      }

      setFormSuccess(
        transferDirection === 'to_cash'
          ? `Transferred ${centsToCurrency(amountCents)} from Bank to Cash wallet!`
          : `Deposited ${centsToCurrency(amountCents)} from Cash to Bank!`
      );
      setAmount('');
      return;
    }

    if (!description.trim()) {
      setFormError('Please enter a description for this transaction');
      return;
    }

    if (actionTab === 'expense') {
      const res = addTransaction({
        description: description.trim(),
        amountCents,
        type: 'expense',
        paymentMethod,
        date: new Date().toISOString(),
        category: essentialCategory ? 'Essential Need' : 'General Spend',
        essentialCategoryId: essentialCategory || undefined,
      });

      if (!res.success) {
        setFormError(res.error || 'Failed to record expense');
        return;
      }

      setFormSuccess(`Recorded expense: ${centsToCurrency(amountCents)} using ${paymentMethod.toUpperCase()}`);
      setDescription('');
      setAmount('');
      setEssentialCategory('');
      return;
    }

    if (actionTab === 'income') {
      const res = addTransaction({
        description: description.trim(),
        amountCents,
        type: 'income',
        paymentMethod,
        date: new Date().toISOString(),
        category: 'Income',
      });

      if (!res.success) {
        setFormError(res.error || 'Failed to record income');
        return;
      }

      setFormSuccess(`Added income: ${centsToCurrency(amountCents)} into ${paymentMethod.toUpperCase()}`);
      setDescription('');
      setAmount('');
      return;
    }
  };

  const filteredTransactions = profile.transactions.filter((tx) => {
    if (historyFilter === 'all') return true;
    if (historyFilter === 'expense') return tx.type === 'expense';
    if (historyFilter === 'income') return tx.type === 'income';
    if (historyFilter === 'transfer')
      return tx.type === 'transfer_to_cash' || tx.type === 'transfer_to_bank';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Wallet Balance Hero Banner */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Bank Wallet Card */}
        <div
          className={`p-5 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} relative overflow-hidden`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/40 border border-blue-400 flex items-center justify-center text-blue-600 dark:text-blue-400 shadow-sm">
                <CreditCard className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-sm uppercase">Bank / Card Wallet</h3>
                <span className="text-[11px] opacity-75">Primary digital account</span>
              </div>
            </div>
            <span className="font-mono text-2xl font-black text-blue-600 dark:text-blue-400">
              {centsToCurrency(metrics.bankBalanceCents)}
            </span>
          </div>
          <p className="text-xs opacity-75">
            Card swipes, autopay bills, and online purchases draw directly from this balance.
          </p>
        </div>

        {/* Physical Cash Wallet Card */}
        <div
          className={`p-5 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} relative overflow-hidden`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 border border-emerald-400 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shadow-sm">
                <Banknote className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-sm uppercase">Physical Cash Wallet</h3>
                <span className="text-[11px] opacity-75">Dollar bills & pocket cash</span>
              </div>
            </div>
            <span className="font-mono text-2xl font-black text-emerald-600 dark:text-emerald-400">
              {centsToCurrency(metrics.cashBalanceCents)}
            </span>
          </div>
          <p className="text-xs opacity-75">
            Physical cash on hand. Remember: cash isn't free—it reduces your total wealth when spent!
          </p>
        </div>
      </div>

      {/* Action Window: Record Spend, Transfer, or Income */}
      <div
        className={`rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} overflow-hidden`}
      >
        {/* Action Window Header */}
        <div
          className={`px-4 py-3 flex items-center justify-between border-b-2 ${
            mode === 'bestie'
              ? 'bg-[#F6D5E3] border-[#A64D79] text-[#A64D79]'
              : 'bg-[#20324E] border-[#4A90E2] text-[#8DD9B5]'
          }`}
        >
          <div className="flex items-center gap-2 font-pixel text-base font-bold">
            <span>{mode === 'bestie' ? '🎀 WALLET_MANAGER.EXE' : '⚡ LIQUIDITY_CONTROLLER.SYS'}</span>
          </div>

          {/* Action Tabs */}
          <div className="flex items-center gap-1 bg-white/70 dark:bg-black/40 p-1 rounded-lg text-xs font-bold">
            <button
              onClick={() => {
                setActionTab('expense');
                setFormError(null);
                setFormSuccess(null);
              }}
              className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                actionTab === 'expense'
                  ? mode === 'bestie'
                    ? 'bg-[#A64D79] text-white shadow'
                    : 'bg-[#4A90E2] text-white shadow'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              Spend Money
            </button>
            <button
              onClick={() => {
                setActionTab('transfer');
                setFormError(null);
                setFormSuccess(null);
              }}
              className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                actionTab === 'transfer'
                  ? mode === 'bestie'
                    ? 'bg-[#A64D79] text-white shadow'
                    : 'bg-[#4A90E2] text-white shadow'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              ATM Transfer ↔
            </button>
            <button
              onClick={() => {
                setActionTab('income');
                setFormError(null);
                setFormSuccess(null);
              }}
              className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                actionTab === 'income'
                  ? mode === 'bestie'
                    ? 'bg-[#A64D79] text-white shadow'
                    : 'bg-[#4A90E2] text-white shadow'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              Add Income
            </button>
          </div>
        </div>

        {/* Action Form */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4">
          {formError && (
            <div className="p-3 bg-red-100 dark:bg-red-950/60 border border-red-400 text-red-700 dark:text-red-300 rounded-lg text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {formSuccess && (
            <div className="p-3 bg-emerald-100 dark:bg-emerald-950/60 border border-emerald-400 text-emerald-800 dark:text-emerald-300 rounded-lg text-xs flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{formSuccess}</span>
            </div>
          )}

          {/* Transfer Form Logic */}
          {actionTab === 'transfer' ? (
            <div className="space-y-4">
              <div className="p-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-300 dark:border-blue-800 rounded-xl text-xs text-blue-900 dark:text-blue-200">
                <span className="font-bold">Transfer Rule: </span>
                Withdrawing or depositing cash moves money between your bank card and physical pocket.
                It is <span className="underline font-bold">NOT</span> considered an expense or new income—your total available money stays exactly the same!
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setTransferDirection('to_cash')}
                  className={`p-3 rounded-xl border-2 text-left cursor-pointer transition-all ${
                    transferDirection === 'to_cash'
                      ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-900/30 ring-2 ring-blue-400/30 font-bold'
                      : 'opacity-70 border-slate-300 dark:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
                    <span className="text-sm">Withdraw Cash (ATM)</span>
                  </div>
                  <span className="text-[11px] opacity-75 font-normal block">
                    Bank balance −$ · Cash balance +$ (Total unchanged)
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setTransferDirection('to_bank')}
                  className={`p-3 rounded-xl border-2 text-left cursor-pointer transition-all ${
                    transferDirection === 'to_bank'
                      ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-900/30 ring-2 ring-blue-400/30 font-bold'
                      : 'opacity-70 border-slate-300 dark:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <ArrowUpRight className="w-4 h-4 text-blue-600" />
                    <span className="text-sm">Deposit Cash into Bank</span>
                  </div>
                  <span className="text-[11px] opacity-75 font-normal block">
                    Cash balance −$ · Bank balance +$ (Total unchanged)
                  </span>
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold mb-1 opacity-80">
                  Transfer Amount ($)
                </label>
                <div className="relative max-w-sm">
                  <span className="absolute left-3 top-2.5 text-xs opacity-50 font-bold">$</span>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="e.g. 50.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className={`w-full pl-7 pr-3 py-2 rounded-lg text-sm font-mono ${theme.inputBg} ${theme.inputBorder}`}
                  />
                </div>
              </div>
            </div>
          ) : (
            /* Spend or Income Form */
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold mb-1 opacity-80">
                    {actionTab === 'expense' ? 'What did you buy?' : 'Income Description'}
                  </label>
                  <input
                    type="text"
                    placeholder={
                      actionTab === 'expense'
                        ? 'e.g. Iced Vanilla Latte, Target haul, Groceries'
                        : 'e.g. Paycheck deposit, Side hustle, Sold jacket'
                    }
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className={`w-full px-3 py-2 rounded-lg text-sm ${theme.inputBg} ${theme.inputBorder}`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold mb-1 opacity-80">Amount ($)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-xs opacity-50 font-bold">$</span>
                    <input
                      type="number"
                      step="0.01"
                      placeholder="e.g. 24.50"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className={`w-full pl-7 pr-3 py-2 rounded-lg text-sm font-mono ${theme.inputBg} ${theme.inputBorder}`}
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold mb-1 opacity-80">
                    Payment Method
                  </label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('bank')}
                      className={`py-2 px-3 rounded-lg border flex items-center justify-center gap-1.5 cursor-pointer font-bold transition-all ${
                        paymentMethod === 'bank'
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 shadow-sm'
                          : 'opacity-70 border-slate-300 dark:border-slate-700'
                      }`}
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>Card / Bank</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cash')}
                      className={`py-2 px-3 rounded-lg border flex items-center justify-center gap-1.5 cursor-pointer font-bold transition-all ${
                        paymentMethod === 'cash'
                          ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-300 shadow-sm'
                          : 'opacity-70 border-slate-300 dark:border-slate-700'
                      }`}
                    >
                      <Banknote className="w-3.5 h-3.5" />
                      <span>Cash In Hand</span>
                    </button>
                  </div>
                </div>

                {actionTab === 'expense' && (
                  <div>
                    <label className="block text-xs font-bold mb-1 opacity-80">
                      Tied to Essential Reserve? <span className="opacity-50">(Optional)</span>
                    </label>
                    <select
                      value={essentialCategory}
                      onChange={(e) => setEssentialCategory(e.target.value)}
                      className={`w-full px-3 py-2 rounded-lg text-xs ${theme.inputBg} ${theme.inputBorder}`}
                    >
                      <option value="">None (Discretionary / Fun spend)</option>
                      {profile.essentials.map((ess) => (
                        <option key={ess.id} value={ess.id}>
                          {ess.name} (Budget remaining: {centsToCurrency(Math.max(0, ess.budgetedCents - ess.spentCents))})
                        </option>
                      ))}
                    </select>
                    <span className="text-[10px] opacity-60 block mt-0.5">
                      Attributing to essentials avoids double-counting against safe-to-spend.
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="pt-2">
            <button
              type="submit"
              className={`w-full sm:w-auto px-6 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer ${theme.primaryButton}`}
            >
              {actionTab === 'transfer' ? (
                <>
                  <ArrowRightLeft className="w-4 h-4" />
                  <span>Execute ATM Transfer</span>
                </>
              ) : actionTab === 'expense' ? (
                <>
                  <MinusCircle className="w-4 h-4" />
                  <span>Confirm Expense</span>
                </>
              ) : (
                <>
                  <PlusCircle className="w-4 h-4" />
                  <span>Deposit Income</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Transaction History Section */}
      <div
        className={`p-5 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} space-y-4`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="font-black text-base uppercase tracking-tight">
              Transaction History
            </h3>
            <p className="text-xs opacity-75">
              Review all debit transactions, cash spending, and ATM transfers.
            </p>
          </div>

          {/* History filter buttons */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs">
            <button
              onClick={() => setHistoryFilter('all')}
              className={`px-3 py-1 rounded font-medium cursor-pointer ${
                historyFilter === 'all'
                  ? 'bg-white dark:bg-slate-700 font-bold shadow-sm'
                  : 'opacity-70'
              }`}
            >
              All ({profile.transactions.length})
            </button>
            <button
              onClick={() => setHistoryFilter('expense')}
              className={`px-3 py-1 rounded font-medium cursor-pointer ${
                historyFilter === 'expense'
                  ? 'bg-white dark:bg-slate-700 font-bold shadow-sm'
                  : 'opacity-70'
              }`}
            >
              Expenses
            </button>
            <button
              onClick={() => setHistoryFilter('transfer')}
              className={`px-3 py-1 rounded font-medium cursor-pointer ${
                historyFilter === 'transfer'
                  ? 'bg-white dark:bg-slate-700 font-bold shadow-sm'
                  : 'opacity-70'
              }`}
            >
              Transfers
            </button>
            <button
              onClick={() => setHistoryFilter('income')}
              className={`px-3 py-1 rounded font-medium cursor-pointer ${
                historyFilter === 'income'
                  ? 'bg-white dark:bg-slate-700 font-bold shadow-sm'
                  : 'opacity-70'
              }`}
            >
              Income
            </button>
          </div>
        </div>

        {/* Transactions Table */}
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {filteredTransactions.length === 0 ? (
            <div className="p-8 text-center text-xs opacity-60 italic">
              No transactions recorded in this filter view.
            </div>
          ) : (
            filteredTransactions.map((tx) => (
              <div
                key={tx.id}
                className={`p-3 rounded-xl border flex items-center justify-between text-xs transition-all ${
                  mode === 'bestie'
                    ? 'bg-white border-[#A64D79]/20 hover:border-[#A64D79]/40'
                    : 'bg-[#18243A] border-[#4A90E2]/30 hover:border-[#4A90E2]/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                      tx.type === 'expense'
                        ? 'bg-red-100 text-red-700'
                        : tx.type === 'income'
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-blue-100 text-blue-700'
                    }`}
                  >
                    {tx.type === 'expense' ? '💸' : tx.type === 'income' ? '💰' : '🔁'}
                  </div>
                  <div>
                    <div className="font-bold flex items-center gap-2">
                      <span>{tx.description}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono">
                        {tx.paymentMethod === 'cash' ? 'Cash' : 'Card'}
                      </span>
                      {tx.essentialCategoryId && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300">
                          Essential
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] opacity-60">
                      {new Date(tx.date).toLocaleDateString()} at{' '}
                      {new Date(tx.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span
                    className={`font-mono font-bold text-sm ${
                      tx.type === 'expense'
                        ? 'text-red-500'
                        : tx.type === 'income'
                        ? 'text-emerald-500'
                        : 'text-blue-500'
                    }`}
                  >
                    {tx.type === 'expense' ? '-' : tx.type === 'income' ? '+' : '↔ '}
                    {centsToCurrency(tx.amountCents)}
                  </span>
                  <button
                    onClick={() => {
                      if (window.confirm(`Delete transaction "${tx.description}"? Funds will be refunded.`)) {
                        deleteTransaction(tx.id);
                      }
                    }}
                    className="p-1 text-slate-400 hover:text-red-500 transition-colors cursor-pointer"
                    title="Refund / Delete Transaction"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
