import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import { THEMES } from '../utils/theme';
import { centsToCurrency, parseToCents } from '../utils/finance';
import { PaymentMethod } from '../types';
import {
  HelpCircle,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  Check,
  BookmarkPlus,
  Trash2,
  SlidersHorizontal,
  ArrowRight,
  ShoppingBag,
} from 'lucide-react';
import { sound } from '../utils/audio';

export const PurchaseChecker: React.FC = () => {
  const { mode, profile, metrics, addTransaction, saveItemForLater, removeSavedItem, unlockAchievement } = useGame();
  const theme = THEMES[mode];

  const [itemName, setItemName] = useState('');
  const [itemAmount, setItemAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bank');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Parse simulated purchase amount
  const purchaseCents = parseToCents(itemAmount);

  // Live simulation computations
  const currentSafeToSpend = metrics.safeToSpendCents;
  const currentTotal = metrics.totalFundsCents;
  const currentSpecificWallet =
    paymentMethod === 'bank' ? metrics.bankBalanceCents : metrics.cashBalanceCents;

  const simRemainingTotal = currentTotal - purchaseCents;
  const simRemainingWallet = currentSpecificWallet - purchaseCents;
  const simRemainingSafeToSpend = currentSafeToSpend - purchaseCents;
  const simDailyAllowance =
    simRemainingSafeToSpend > 0
      ? Math.floor(simRemainingSafeToSpend / metrics.daysRemaining)
      : 0;

  // Determine status of this simulated purchase
  let resultTier: 'green' | 'yellow' | 'red' = 'green';
  if (purchaseCents > 0) {
    if (simRemainingSafeToSpend < 0 || simRemainingWallet < 0) {
      resultTier = 'red';
    } else if (
      simRemainingSafeToSpend < currentTotal * 0.2 ||
      simDailyAllowance < 1000 ||
      purchaseCents > currentSafeToSpend * 0.6
    ) {
      resultTier = 'yellow';
    } else {
      resultTier = 'green';
    }
  }

  // Pre-calculated target "responsible price" (e.g., maximum safe to spend without going red/yellow)
  const maxSafePriceCents = Math.max(0, currentSafeToSpend);

  const handleConfirmPurchase = () => {
    if (!itemName.trim() || purchaseCents <= 0) return;

    const res = addTransaction({
      description: itemName.trim(),
      amountCents: purchaseCents,
      type: 'expense',
      paymentMethod,
      date: new Date().toISOString(),
      category: 'Simulated Purchase',
      isDeluluPurchase: resultTier === 'red',
    });

    if (res.success) {
      setSuccessMessage(`Purchased "${itemName}" for ${centsToCurrency(purchaseCents)}! Balance updated.`);
      setItemName('');
      setItemAmount('');
    } else {
      alert(res.error || 'Could not complete purchase');
    }
  };

  const handleSaveForLater = () => {
    if (!itemName.trim() || purchaseCents <= 0) return;
    saveItemForLater(itemName.trim(), purchaseCents);
    setSuccessMessage(`Added "${itemName}" to your wishlist. Smart move dodging the impulse!`);
    setItemName('');
    setItemAmount('');
  };

  return (
    <div className="space-y-6">
      {/* Title Header */}
      <div
        className={`p-5 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} relative overflow-hidden`}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">{mode === 'bestie' ? '🎀' : '🕹️'}</span>
              <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight">
                {mode === 'bestie'
                  ? 'Delulu or Responsible? Purchase Checker'
                  : 'System Purchase Risk Evaluator'}
              </h2>
            </div>
            <p className="text-xs opacity-75 mt-1 max-w-xl">
              {mode === 'bestie'
                ? 'Before you tap that card or open Apple Pay, test your purchase. See exactly how it affects your safe-to-spend money and daily survival allowance!'
                : 'Simulate liquidity depletion parameters prior to authorizing transactional commitment.'}
            </p>
          </div>

          <div
            className={`p-3 rounded-xl border text-xs ${
              mode === 'bestie' ? 'bg-[#F6D5E3]/60 border-[#A64D79]/30' : 'bg-[#18243A] border-[#4A90E2]/40'
            }`}
          >
            <span className="opacity-70 text-[10px] uppercase font-bold block">Current Safe-to-Spend</span>
            <span className="font-mono text-lg font-black text-emerald-600 dark:text-emerald-400">
              {centsToCurrency(currentSafeToSpend)}
            </span>
          </div>
        </div>
      </div>

      {/* Main Interactive Checker Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Purchase Input Form (5 cols) */}
        <div
          className={`lg:col-span-5 p-5 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} space-y-4`}
        >
          <h3 className="font-bold text-sm uppercase tracking-wider">
            1. Enter Item Details
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold mb-1 opacity-80">
                Item / Purchase Name
              </label>
              <input
                type="text"
                placeholder="e.g. Designer sunglasses, Sushi takeout, Sneakers"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                className={`w-full px-3 py-2 rounded-lg text-sm ${theme.inputBg} ${theme.inputBorder}`}
              />
            </div>

            <div>
              <label className="block text-xs font-bold mb-1 opacity-80">
                Price Tag ($)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-xs opacity-50 font-bold">$</span>
                <input
                  type="number"
                  step="0.01"
                  placeholder="e.g. 68.00"
                  value={itemAmount}
                  onChange={(e) => setItemAmount(e.target.value)}
                  className={`w-full pl-7 pr-3 py-2 rounded-lg text-sm font-mono ${theme.inputBg} ${theme.inputBorder}`}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold mb-1 opacity-80">
                Payment Source
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('bank')}
                  className={`py-2 px-3 rounded-lg border flex items-center justify-center gap-1.5 cursor-pointer font-bold transition-all ${
                    paymentMethod === 'bank'
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 font-bold'
                      : 'opacity-70 border-slate-300 dark:border-slate-700'
                  }`}
                >
                  <span>Card / Bank</span>
                  <span className="text-[10px] font-mono">({centsToCurrency(metrics.bankBalanceCents)})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('cash')}
                  className={`py-2 px-3 rounded-lg border flex items-center justify-center gap-1.5 cursor-pointer font-bold transition-all ${
                    paymentMethod === 'cash'
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-300 font-bold'
                      : 'opacity-70 border-slate-300 dark:border-slate-700'
                  }`}
                >
                  <span>Cash Wallet</span>
                  <span className="text-[10px] font-mono">({centsToCurrency(metrics.cashBalanceCents)})</span>
                </button>
              </div>
            </div>

            {/* Quick Price Preset Buttons */}
            <div>
              <span className="text-[11px] opacity-70 block mb-1">Quick Sample Presets:</span>
              <div className="flex flex-wrap gap-1.5 text-xs">
                {[
                  { label: 'Matcha $7', amount: '7.00' },
                  { label: 'Dinner $35', amount: '35.00' },
                  { label: 'Shoes $90', amount: '90.00' },
                  { label: 'Splurge $250', amount: '250.00' },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      setItemName(preset.label.split(' ')[0]);
                      setItemAmount(preset.amount);
                    }}
                    className={`px-2 py-1 rounded border text-[11px] font-medium cursor-pointer ${
                      mode === 'bestie'
                        ? 'bg-[#F6D5E3]/40 border-[#A64D79]/20 hover:bg-[#F6D5E3]'
                        : 'bg-[#18243A] border-[#4A90E2]/30 hover:bg-[#20324E]'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Live Outcome Simulator (7 cols) */}
        <div
          className={`lg:col-span-7 p-5 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} flex flex-col justify-between space-y-4`}
        >
          {purchaseCents <= 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-3 opacity-60">
              <ShoppingBag className="w-12 h-12 text-[#A64D79] dark:text-[#8DD9B5]" />
              <p className="text-sm font-bold">
                {mode === 'bestie'
                  ? 'Enter an amount to see if this purchase is Delulu or Responsible!'
                  : 'Enter transaction parameters to execute risk telemetry calculation.'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Verdict Banner */}
              <div
                className={`p-4 rounded-xl border-2 text-center transition-all ${
                  resultTier === 'green'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-200'
                    : resultTier === 'yellow'
                    ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-500 text-amber-900 dark:text-amber-200'
                    : 'bg-rose-50 dark:bg-rose-950/40 border-rose-500 text-rose-900 dark:text-rose-200'
                }`}
              >
                <div className="text-2xl mb-1">
                  {resultTier === 'green' ? '💚' : resultTier === 'yellow' ? '💛' : '❤️'}
                </div>
                <h4 className="text-lg sm:text-xl font-black tracking-tight uppercase">
                  {mode === 'bestie' ? (
                    resultTier === 'green' ? (
                      "RESPONSIBLE BESTIE! 💚 You're staying on track!"
                    ) : resultTier === 'yellow' ? (
                      'BESTIE, THINK AGAIN! 💛 This makes payday tighter.'
                    ) : (
                      'DELULU ALERT! ❤️ Girl, your wallet cannot handle this right now!'
                    )
                  ) : resultTier === 'green' ? (
                    "PURCHASE CLEARED! You're within your spending plan."
                  ) : resultTier === 'yellow' ? (
                    'CAUTION! This purchase reduces your financial flexibility.'
                  ) : (
                    'BUDGET OVERLOAD! This purchase puts essential expenses at risk.'
                  )}
                </h4>
                <p className="text-xs mt-1 opacity-90 max-w-md mx-auto">
                  {resultTier === 'green'
                    ? 'You have plenty of safe-to-spend buffer left over after paying this.'
                    : resultTier === 'yellow'
                    ? 'This will drop your daily discretionary spending down to a razor thin line.'
                    : 'Buying this threatens reserved money needed for scheduled bills or groceries!'}
                </p>
              </div>

              {/* Simulation Impact Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                <div className={`p-2.5 rounded-lg border ${theme.statBoxBg} ${theme.statBoxBorder}`}>
                  <span className="opacity-70 text-[10px] uppercase font-bold block">Safe-to-Spend Left</span>
                  <div className="flex items-center gap-1 font-mono font-bold">
                    <span className="line-through opacity-50">{centsToCurrency(currentSafeToSpend)}</span>
                    <span className="text-slate-400">→</span>
                    <span
                      className={`text-sm ${
                        simRemainingSafeToSpend < 0 ? 'text-rose-600' : 'text-emerald-600'
                      }`}
                    >
                      {centsToCurrency(simRemainingSafeToSpend)}
                    </span>
                  </div>
                </div>

                <div className={`p-2.5 rounded-lg border ${theme.statBoxBg} ${theme.statBoxBorder}`}>
                  <span className="opacity-70 text-[10px] uppercase font-bold block">Daily Allowance</span>
                  <div className="flex items-center gap-1 font-mono font-bold">
                    <span className="line-through opacity-50">{centsToCurrency(metrics.dailyAllowanceCents)}</span>
                    <span className="text-slate-400">→</span>
                    <span className="text-sm text-blue-600">
                      {centsToCurrency(simDailyAllowance)}
                    </span>
                  </div>
                </div>

                <div className={`p-2.5 rounded-lg border ${theme.statBoxBg} ${theme.statBoxBorder}`}>
                  <span className="opacity-70 text-[10px] uppercase font-bold block">
                    {paymentMethod === 'bank' ? 'Bank Card Left' : 'Cash in Hand Left'}
                  </span>
                  <span
                    className={`font-mono font-bold text-sm block ${
                      simRemainingWallet < 0 ? 'text-rose-600' : ''
                    }`}
                  >
                    {centsToCurrency(simRemainingWallet)}
                  </span>
                </div>
              </div>

              {/* "Try a Cheaper Price" Slider */}
              <div
                className={`p-3 rounded-xl border text-xs space-y-2 ${
                  mode === 'bestie' ? 'bg-[#FFF9F3] border-[#A64D79]/20' : 'bg-[#131D2E] border-[#4A90E2]/30'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold flex items-center gap-1 text-[11px]">
                    <SlidersHorizontal className="w-3.5 h-3.5" />
                    <span>Try a Cheaper Price / Negotiation Slider:</span>
                  </span>
                  <span className="font-mono text-emerald-600 font-bold">
                    Safe ceiling: {centsToCurrency(maxSafePriceCents)}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max={Math.max(purchaseCents, maxSafePriceCents * 2)}
                  value={purchaseCents}
                  onChange={(e) => setItemAmount((Number(e.target.value) / 100).toFixed(2))}
                  className="w-full accent-[#A64D79] cursor-pointer"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleConfirmPurchase}
                  className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 cursor-pointer ${
                    resultTier === 'red'
                      ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-[2px_2px_0px_#4c0519]'
                      : theme.primaryButton
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span>
                    {resultTier === 'red'
                      ? 'Confirm Purchase Anyway (Risk!)'
                      : 'Confirm Purchase'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveForLater}
                  className={`py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${theme.secondaryButton}`}
                  title="Put on wishlist and save money until payday"
                >
                  <BookmarkPlus className="w-4 h-4" />
                  <span>Save For Later (Smart)</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setItemName('');
                    setItemAmount('');
                  }}
                  className="py-2.5 px-3 rounded-xl text-xs font-medium opacity-60 hover:opacity-100 cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {successMessage && (
            <div className="p-3 bg-emerald-100 text-emerald-800 rounded-lg text-xs font-bold">
              {successMessage}
            </div>
          )}
        </div>
      </div>

      {/* Saved For Later / Smart Wishlist Section */}
      <div
        className={`p-5 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} space-y-3`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookmarkPlus className="w-4 h-4 text-purple-500" />
            <h3 className="font-black text-sm uppercase tracking-tight">
              {mode === 'bestie' ? 'Saved For Next Payday 💖' : 'Deferred Purchase Registry 📋'}
            </h3>
          </div>
          <span className="text-xs opacity-60 font-mono">
            {profile.savedItems.length} items saved
          </span>
        </div>

        {profile.savedItems.length === 0 ? (
          <p className="text-xs opacity-60 italic py-2">
            No items saved for later yet. Whenever you resist an impulse splurge, click "Save For Later" to park it here!
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {profile.savedItems.map((item) => (
              <div
                key={item.id}
                className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                  mode === 'bestie' ? 'bg-[#FFF9F3] border-[#A64D79]/20' : 'bg-[#131D2E] border-[#4A90E2]/30'
                }`}
              >
                <div>
                  <span className="font-bold block">{item.name}</span>
                  <span className="font-mono text-xs opacity-75">
                    {centsToCurrency(item.amountCents)}
                  </span>
                </div>
                <button
                  onClick={() => removeSavedItem(item.id)}
                  className="p-1 text-slate-400 hover:text-red-500 cursor-pointer"
                  title="Remove from saved items"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
