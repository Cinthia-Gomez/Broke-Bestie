import React from 'react';
import { useGame } from '../context/GameContext';
import { THEMES } from '../utils/theme';
import { Volume2, VolumeX, Sparkles, Gamepad2, Heart, RotateCcw } from 'lucide-react';

export const Header: React.FC<{ onOpenSetup: () => void }> = ({ onOpenSetup }) => {
  const { mode, setMode, activeTab, setActiveTab, isMuted, toggleMute, resetAllData } = useGame();
  const theme = THEMES[mode];

  const navLinks = [
    { id: 'dashboard', labelBestie: 'Dashboard', labelClassic: 'Command Center' },
    { id: 'transactions', labelBestie: 'Wallets & Cash', labelClassic: 'Liquidity Pools' },
    { id: 'purchase_checker', labelBestie: 'Purchase Checker', labelClassic: 'Purchase Simulator' },
    { id: 'girl_math', labelBestie: 'Girl Math.exe', labelClassic: 'Money Myths' },
    { id: 'rescue', labelBestie: 'Rescue Budget', labelClassic: 'Recovery Protocol' },
    { id: 'achievements', labelBestie: 'Badges & Level', labelClassic: 'Trophies & Rank' },
  ];

  return (
    <header className={`w-full sticky top-0 z-40 transition-colors duration-200 border-b ${
      mode === 'bestie'
        ? 'bg-[#FFF4E8]/95 backdrop-blur-md border-[#A64D79]/20'
        : 'bg-[#0E1726]/95 backdrop-blur-md border-[#4A90E2]/30'
    }`}>
      {/* Y2K Windows-Style Title Strip */}
      <div className={`px-4 py-1 text-xs flex items-center justify-between font-mono ${
        mode === 'bestie'
          ? 'bg-gradient-to-r from-[#F6D5E3] via-[#E8DDF5] to-[#F6D5E3] text-[#A64D79] border-b border-[#A64D79]/20'
          : 'bg-[#18243A] text-[#8DD9B5] border-b border-[#4A90E2]/20'
      }`}>
        <div className="flex items-center gap-2 font-pixel tracking-wider">
          <span>{mode === 'bestie' ? '🎀 BROKE_BESTIE_OS // v1.0-RELEASE' : '🕹️ SURVIVAL_KERNEL // SYS.LEVEL_1'}</span>
          <span className="opacity-50">|</span>
          <span className="text-[11px] font-sans">Survive payday, one questionable purchase at a time.</span>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={toggleMute}
            title={isMuted ? 'Unmute Sound FX' : 'Mute Sound FX'}
            className="flex items-center gap-1 hover:opacity-80 transition-opacity cursor-pointer font-sans"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline text-[11px]">{isMuted ? 'Muted' : 'Audio ON'}</span>
          </button>
          <button
            onClick={() => {
              if (window.confirm('Reset all financial data and restart setup?')) {
                resetAllData();
              }
            }}
            title="Reset Game State"
            className="flex items-center gap-1 hover:opacity-80 transition-opacity cursor-pointer text-[11px] font-sans"
          >
            <RotateCcw className="w-3 h-3" />
            <span className="hidden sm:inline">Reset</span>
          </button>
        </div>
      </div>

      {/* Main Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Brand Wordmark */}
        <button
          onClick={() => setActiveTab('dashboard')}
          className="flex items-center gap-2 group text-left whitespace-nowrap shrink-0 cursor-pointer"
        >
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-lg border ${
            mode === 'bestie'
              ? 'bg-[#F6D5E3] text-[#A64D79] border-[#A64D79]/40 shadow-[2px_2px_0px_#A64D79]'
              : 'bg-[#18243A] text-[#8DD9B5] border-[#4A90E2] shadow-[2px_2px_0px_#4A90E2]'
          }`}>
            {mode === 'bestie' ? '💗' : '🎮'}
          </div>
          <span className={`text-lg sm:text-xl font-black tracking-tight ${
            mode === 'bestie' ? 'text-[#A64D79]' : 'text-[#8DD9B5]'
          }`}>
            Broke Bestie<span className="font-pixel text-sm font-normal opacity-75">.exe</span>
          </span>
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-xs xl:text-sm font-semibold">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            const label = mode === 'bestie' ? link.labelBestie : link.labelClassic;
            return (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className={`px-3 py-1.5 rounded-md whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? mode === 'bestie'
                      ? 'bg-[#A64D79] text-white shadow-sm'
                      : 'bg-[#4A90E2] text-white shadow-sm'
                    : mode === 'bestie'
                    ? 'text-[#7A3656] hover:bg-[#F6D5E3]/60'
                    : 'text-[#DDE4EC] hover:bg-[#18243A]'
                }`}
              >
                {label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Action & Mode Switcher */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Mode Switcher Button */}
          <button
            onClick={() => setMode(mode === 'bestie' ? 'classic' : 'bestie')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 border cursor-pointer transition-all ${
              mode === 'bestie'
                ? 'bg-white hover:bg-slate-50 text-[#A64D79] border-[#A64D79]/40 shadow-[2px_2px_0px_#A64D79]'
                : 'bg-[#18243A] hover:bg-[#20324E] text-[#8DD9B5] border-[#4A90E2]/60 shadow-[2px_2px_0px_#4A90E2]'
            }`}
            title="Switch between Bestie Mode and Classic Mode"
          >
            {mode === 'bestie' ? (
              <>
                <Gamepad2 className="w-3.5 h-3.5 text-blue-500" />
                <span className="whitespace-nowrap">Switch to Classic</span>
              </>
            ) : (
              <>
                <Heart className="w-3.5 h-3.5 text-pink-500 fill-pink-500" />
                <span className="whitespace-nowrap">Switch to Bestie</span>
              </>
            )}
          </button>

          {/* Quick Setup / Edit Profile */}
          <button
            onClick={onOpenSetup}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap cursor-pointer ${theme.primaryButton}`}
          >
            {mode === 'bestie' ? 'Edit Budget ✏️' : 'Budget Setup ⚙️'}
          </button>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="lg:hidden flex items-center overflow-x-auto py-2 px-3 gap-1 border-t border-inherit no-scrollbar">
        {navLinks.map((link) => {
          const isActive = activeTab === link.id;
          const label = mode === 'bestie' ? link.labelBestie : link.labelClassic;
          return (
            <button
              key={link.id}
              onClick={() => setActiveTab(link.id)}
              className={`px-2.5 py-1 text-xs font-semibold rounded whitespace-nowrap cursor-pointer shrink-0 ${
                isActive
                  ? mode === 'bestie'
                    ? 'bg-[#A64D79] text-white'
                    : 'bg-[#4A90E2] text-white'
                  : mode === 'bestie'
                  ? 'text-[#7A3656] bg-[#F6D5E3]/40'
                  : 'text-[#DDE4EC] bg-[#18243A]'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>
    </header>
  );
};
