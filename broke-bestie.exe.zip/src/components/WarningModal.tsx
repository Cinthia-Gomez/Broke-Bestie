import React from 'react';
import { useGame } from '../context/GameContext';
import { THEMES } from '../utils/theme';
import { centsToCurrency } from '../utils/finance';
import { AlertOctagon, ShieldAlert, ArrowRight, X, HeartCrack, Flame } from 'lucide-react';
import { sound } from '../utils/audio';

export const WarningModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onOpenRescue: () => void;
  onOpenExpenses: () => void;
}> = ({ isOpen, onClose, onOpenRescue, onOpenExpenses }) => {
  const { mode, metrics } = useGame();
  const theme = THEMES[mode];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div
        className={`w-full max-w-lg rounded-2xl border-4 ${
          mode === 'bestie'
            ? 'bg-[#FFF4E8] border-[#D94B65] shadow-[8px_8px_0px_#D94B65]'
            : 'bg-[#18243A] border-rose-500 shadow-[8px_8px_0px_#f43f5e] text-white'
        } overflow-hidden transform transition-all scale-100`}
      >
        {/* Retro Alert Titlebar */}
        <div
          className={`px-4 py-2.5 flex items-center justify-between border-b-2 ${
            mode === 'bestie'
              ? 'bg-[#F6D5E3] border-[#D94B65] text-[#D94B65]'
              : 'bg-rose-950/80 border-rose-500 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2 font-pixel text-base font-bold">
            <AlertOctagon className="w-5 h-5 animate-bounce" />
            <span>{mode === 'bestie' ? '⚠️ CRITICAL_BESTIE_ALERT.SYS' : '🚨 LEVEL_CRITICAL_HAZARD'}</span>
          </div>
          <button
            onClick={() => {
              sound.playBlip(300);
              onClose();
            }}
            className="p-1 rounded hover:opacity-75 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Alert Body */}
        <div className="p-6 text-center space-y-4">
          <div className="flex justify-center">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center text-3xl border-3 ${
                mode === 'bestie'
                  ? 'bg-rose-100 border-[#D94B65] text-[#D94B65] shadow-[3px_3px_0px_#D94B65]'
                  : 'bg-rose-900/50 border-rose-500 text-rose-400 shadow-[3px_3px_0px_#f43f5e]'
              }`}
            >
              {mode === 'bestie' ? '💔' : '⚠️'}
            </div>
          </div>

          <div>
            <h2
              className={`text-xl sm:text-2xl font-black uppercase tracking-tight ${
                mode === 'bestie' ? 'text-[#D94B65]' : 'text-rose-400'
              }`}
            >
              {mode === 'bestie'
                ? '🚨 GIRL, WE HAVE A PROBLEM!'
                : '🚨 LOW FUNDS ALERT!'}
            </h2>
            <p className="text-sm font-bold mt-1 opacity-90">
              {mode === 'bestie'
                ? 'Your wallet is entering its broke era!'
                : 'Your payday survival budget is at risk!'}
            </p>
          </div>

          <div
            className={`p-4 rounded-xl border text-xs text-left space-y-2 ${
              mode === 'bestie'
                ? 'bg-white border-[#D94B65]/30 text-slate-800'
                : 'bg-[#131D2E] border-rose-500/40 text-slate-200'
            }`}
          >
            <div className="flex justify-between items-center font-bold">
              <span>Estimated Shortfall:</span>
              <span className="font-mono text-rose-600 text-sm">
                {centsToCurrency(metrics.shortfallCents)}
              </span>
            </div>
            <div className="flex justify-between items-center opacity-80">
              <span>Days Until Payday:</span>
              <span className="font-mono">{metrics.daysRemaining} days</span>
            </div>
            <div className="flex justify-between items-center opacity-80">
              <span>Reserved for Bills & Food:</span>
              <span className="font-mono">{centsToCurrency(metrics.reservedFundsCents)}</span>
            </div>
            <p className="text-[11px] pt-1 opacity-75 border-t border-inherit">
              {mode === 'bestie'
                ? 'Your upcoming bills and essential needs exceed your available total money. Time to deploy recovery mode before payday!'
                : 'Projected expenditures threaten scheduled bill execution or essential sustenance allocation.'}
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-2 pt-2">
            <button
              onClick={() => {
                onClose();
                onOpenRescue();
              }}
              className="flex-1 py-3 px-4 rounded-xl font-black text-sm bg-rose-600 hover:bg-rose-700 text-white border-2 border-rose-950 shadow-[3px_3px_0px_#4c0519] flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Rescue My Budget 🆘</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onOpenExpenses();
              }}
              className={`py-3 px-4 rounded-xl font-bold text-xs cursor-pointer border ${
                mode === 'bestie'
                  ? 'bg-white hover:bg-slate-50 text-[#A64D79] border-[#A64D79]/40'
                  : 'bg-[#20324E] hover:bg-[#283e61] text-[#8DD9B5] border-[#4A90E2]/40'
              }`}
            >
              View Expenses 📋
            </button>

            <button
              onClick={() => {
                sound.playBlip(300);
                onClose();
              }}
              className="py-3 px-3 rounded-xl font-semibold text-xs opacity-60 hover:opacity-100 cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
