import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import { THEMES } from '../utils/theme';
import { centsToCurrency } from '../utils/finance';
import { WalletHealthBar } from './WalletHealthBar';
import {
  Wallet,
  CreditCard,
  Banknote,
  Calendar,
  Lock,
  PlusCircle,
  HelpCircle,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Clock,
  ShieldCheck,
  TrendingUp,
  Receipt,
  FileQuestion,
} from 'lucide-react';
import { sound } from '../utils/audio';

export const Dashboard: React.FC<{
  onOpenSetup: () => void;
  onOpenQuickTx: (type?: 'expense' | 'income' | 'transfer') => void;
}> = ({ onOpenSetup, onOpenQuickTx }) => {
  const { mode, profile, metrics, setActiveTab, toggleBillPaid } = useGame();
  const theme = THEMES[mode];

  // Quick state for filter
  const [filterBills, setFilterBills] = useState<'all' | 'unpaid' | 'paid'>('all');

  const visibleBills = profile.bills.filter((b) => {
    if (filterBills === 'unpaid') return !b.isPaid;
    if (filterBills === 'paid') return b.isPaid;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* 1. Wallet Health Bar (Prominent Game HUD) */}
      <WalletHealthBar onOpenRescue={() => setActiveTab('rescue')} />

      {/* 2. Primary KPI Grid (Integer Cents Accurate) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Available Funds */}
        <div
          className={`p-4 rounded-xl border-2 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} flex flex-col justify-between`}
        >
          <div className="flex items-center justify-between opacity-80 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">
              {mode === 'bestie' ? 'Total Money 💰' : 'Total Liquidity 💎'}
            </span>
            <Wallet className="w-4 h-4 text-[#A64D79] dark:text-[#8DD9B5]" />
          </div>
          <div className="space-y-1">
            <span className="text-2xl sm:text-3xl font-black font-mono tracking-tight">
              {centsToCurrency(metrics.totalFundsCents)}
            </span>
            <div className="flex items-center justify-between text-[11px] opacity-75 pt-1 border-t border-inherit">
              <span>Bank: {centsToCurrency(metrics.bankBalanceCents)}</span>
              <span>Cash: {centsToCurrency(metrics.cashBalanceCents)}</span>
            </div>
          </div>
        </div>

        {/* Reserved Funds */}
        <div
          className={`p-4 rounded-xl border-2 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} flex flex-col justify-between`}
        >
          <div className="flex items-center justify-between opacity-80 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">
              {mode === 'bestie' ? 'Locked For Bills & Needs 🔒' : 'Committed Escrow 🔒'}
            </span>
            <Lock className="w-4 h-4 text-purple-500" />
          </div>
          <div className="space-y-1">
            <span className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-purple-600 dark:text-purple-400">
              {centsToCurrency(metrics.reservedFundsCents)}
            </span>
            <div className="flex items-center justify-between text-[11px] opacity-75 pt-1 border-t border-inherit">
              <span>Unpaid Bills: {centsToCurrency(metrics.unpaidBillsCents)}</span>
              <span>Needs: {centsToCurrency(metrics.remainingEssentialsCents)}</span>
            </div>
          </div>
        </div>

        {/* Safe-to-Spend Balance */}
        <div
          className={`p-4 rounded-xl border-2 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} flex flex-col justify-between`}
        >
          <div className="flex items-center justify-between opacity-80 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">
              {mode === 'bestie' ? 'Safe to Spend 💅' : 'Discretionary Buffer 🛡️'}
            </span>
            <Sparkles className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="space-y-1">
            <span
              className={`text-2xl sm:text-3xl font-black font-mono tracking-tight ${
                metrics.safeToSpendCents < 0
                  ? 'text-red-500'
                  : 'text-emerald-600 dark:text-emerald-400'
              }`}
            >
              {centsToCurrency(metrics.safeToSpendCents)}
            </span>
            <div className="flex items-center justify-between text-[11px] opacity-75 pt-1 border-t border-inherit">
              <span>Total − Reserved</span>
              <span className="font-semibold">
                {metrics.safeToSpendCents < 0 ? 'Deficit' : 'Guilt-Free'}
              </span>
            </div>
          </div>
        </div>

        {/* Daily Allowance & Countdown */}
        <div
          className={`p-4 rounded-xl border-2 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} flex flex-col justify-between`}
        >
          <div className="flex items-center justify-between opacity-80 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">
              {mode === 'bestie' ? 'Daily Allowance 📅' : 'Daily Burn Ceiling ⏱️'}
            </span>
            <Clock className="w-4 h-4 text-blue-500" />
          </div>
          <div className="space-y-1">
            <span className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-blue-600 dark:text-blue-400">
              {centsToCurrency(metrics.dailyAllowanceCents)}
              <span className="text-xs font-normal opacity-75 font-sans ml-1">/ day</span>
            </span>
            <div className="flex items-center justify-between text-[11px] opacity-75 pt-1 border-t border-inherit">
              <span>{metrics.daysRemaining} days until payday</span>
              <span className="font-mono text-[10px]">({profile.nextPaydayDate})</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Interactive Quick Actions Bar */}
      <div
        className={`p-4 rounded-xl border-2 ${theme.cardBg} ${theme.cardBorder} flex flex-wrap items-center justify-between gap-3`}
      >
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider opacity-70">
            {mode === 'bestie' ? 'Quick Actions:' : 'Operational Commands:'}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onOpenQuickTx('expense')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${theme.primaryButton}`}
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Record Spend</span>
          </button>

          <button
            onClick={() => onOpenQuickTx('transfer')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${theme.secondaryButton}`}
          >
            <Banknote className="w-3.5 h-3.5" />
            <span>Withdraw / Deposit Cash</span>
          </button>

          <button
            onClick={() => setActiveTab('purchase_checker')}
            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white flex items-center gap-1.5 cursor-pointer shadow-[2px_2px_0px_#78350f]"
          >
            <FileQuestion className="w-3.5 h-3.5" />
            <span>Check Purchase (Delulu?)</span>
          </button>

          <button
            onClick={() => setActiveTab('girl_math')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer border ${
              mode === 'bestie'
                ? 'bg-[#F6D5E3] text-[#A64D79] border-[#A64D79]/40'
                : 'bg-[#20324E] text-[#8DD9B5] border-[#4A90E2]/40'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{mode === 'bestie' ? 'Girl Math.exe' : 'Money Myths'}</span>
          </button>
        </div>
      </div>

      {/* 4. Two-Column Layout: Dual Wallets & Bills Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Dual Wallet Status Card */}
        <div
          className={`p-5 rounded-2xl border-2 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} space-y-4`}
        >
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-black text-base uppercase tracking-tight">
                {mode === 'bestie' ? 'Your Two Wallets 👛' : 'Liquidity Allocations 💳'}
              </h3>
              <p className="text-xs opacity-75">
                Bank card vs. Physical cash tracking (Cash withdrawals are transfers, not expenses!)
              </p>
            </div>
            <button
              onClick={() => setActiveTab('transactions')}
              className="text-xs font-bold text-blue-500 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>Full History</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Bank Wallet Card */}
            <div
              className={`p-4 rounded-xl border ${theme.statBoxBg} ${theme.statBoxBorder} relative overflow-hidden`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold opacity-80 flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-blue-500" />
                  <span>Bank / Debit</span>
                </span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-blue-100 text-blue-800">
                  Digital
                </span>
              </div>
              <span className="text-xl sm:text-2xl font-black font-mono block">
                {centsToCurrency(metrics.bankBalanceCents)}
              </span>
              <p className="text-[11px] opacity-70 mt-1">Available on card for online or swipe</p>
            </div>

            {/* Cash Wallet Card */}
            <div
              className={`p-4 rounded-xl border ${theme.statBoxBg} ${theme.statBoxBorder} relative overflow-hidden`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold opacity-80 flex items-center gap-1.5">
                  <Banknote className="w-4 h-4 text-emerald-500" />
                  <span>Physical Cash</span>
                </span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                  Cash in Hand
                </span>
              </div>
              <span className="text-xl sm:text-2xl font-black font-mono block">
                {centsToCurrency(metrics.cashBalanceCents)}
              </span>
              <p className="text-[11px] opacity-70 mt-1">Dollar bills and coins in your pocket</p>
            </div>
          </div>

          {/* Quick Cash Withdrawal Explanation Banner */}
          <div
            className={`p-3 rounded-lg text-xs border flex items-start gap-2.5 ${
              mode === 'bestie'
                ? 'bg-[#F6D5E3]/40 border-[#A64D79]/20 text-[#541c38]'
                : 'bg-[#131D2E] border-[#4A90E2]/30 text-slate-300'
            }`}
          >
            <HelpCircle className="w-4 h-4 shrink-0 text-amber-500 mt-0.5" />
            <div>
              <span className="font-bold">Golden Rule: Cash is NOT "free money"!</span>
              <p className="text-[11px] opacity-80 mt-0.5">
                Withdrawing $50 moves money from your bank to your pocket. Spending that $20 cash reduces your total wealth!
              </p>
            </div>
          </div>

          {/* Recent Transactions Snippet */}
          <div className="space-y-2 pt-1">
            <span className="text-xs font-bold uppercase tracking-wider opacity-70 block">
              Recent Activity
            </span>
            {profile.transactions.slice(0, 3).map((tx) => (
              <div
                key={tx.id}
                className={`p-2.5 rounded-lg border text-xs flex items-center justify-between ${
                  mode === 'bestie' ? 'bg-white border-[#A64D79]/15' : 'bg-[#18243A] border-[#4A90E2]/20'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="font-bold">{tx.description}</span>
                  <span className="text-[10px] opacity-60 font-mono">
                    [{tx.paymentMethod === 'cash' ? '💵 Cash' : '💳 Card'}]
                  </span>
                </div>
                <span
                  className={`font-mono font-bold ${
                    tx.type === 'expense'
                      ? 'text-red-500'
                      : tx.type === 'income'
                      ? 'text-emerald-500'
                      : 'text-blue-500'
                  }`}
                >
                  {tx.type === 'expense' ? '-' : tx.type === 'income' ? '+' : '↔ '}
                  {centsToCurrency(tx.amountCents)}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Bills & Essential Reserves Card */}
        <div
          className={`p-5 rounded-2xl border-2 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} space-y-4`}
        >
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-black text-base uppercase tracking-tight">
                {mode === 'bestie' ? 'Upcoming Bills & Escrow 📋' : 'Scheduled Obligations 📋'}
              </h3>
              <p className="text-xs opacity-75">
                Click checkboxes to mark paid when settled (releases reserved funds)
              </p>
            </div>
            <button
              onClick={onOpenSetup}
              className="text-xs font-bold text-[#A64D79] dark:text-[#8DD9B5] hover:underline cursor-pointer"
            >
              + Add Bill
            </button>
          </div>

          {/* Filter segment */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs">
            <button
              onClick={() => setFilterBills('all')}
              className={`px-3 py-1 rounded font-medium cursor-pointer ${
                filterBills === 'all'
                  ? 'bg-white dark:bg-slate-700 shadow-sm font-bold'
                  : 'opacity-70'
              }`}
            >
              All ({profile.bills.length})
            </button>
            <button
              onClick={() => setFilterBills('unpaid')}
              className={`px-3 py-1 rounded font-medium cursor-pointer ${
                filterBills === 'unpaid'
                  ? 'bg-white dark:bg-slate-700 shadow-sm font-bold'
                  : 'opacity-70'
              }`}
            >
              Unpaid ({profile.bills.filter((b) => !b.isPaid).length})
            </button>
            <button
              onClick={() => setFilterBills('paid')}
              className={`px-3 py-1 rounded font-medium cursor-pointer ${
                filterBills === 'paid'
                  ? 'bg-white dark:bg-slate-700 shadow-sm font-bold'
                  : 'opacity-70'
              }`}
            >
              Paid ({profile.bills.filter((b) => b.isPaid).length})
            </button>
          </div>

          {/* Bills List */}
          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {visibleBills.length === 0 ? (
              <div className="p-6 text-center text-xs opacity-60 italic">
                No bills found in this view.
              </div>
            ) : (
              visibleBills.map((bill) => (
                <div
                  key={bill.id}
                  onClick={() => toggleBillPaid(bill.id)}
                  className={`p-3 rounded-xl border flex items-center justify-between text-xs cursor-pointer transition-all ${
                    bill.isPaid
                      ? 'opacity-60 bg-slate-50 dark:bg-slate-900 border-dashed border-slate-300 dark:border-slate-700 line-through'
                      : mode === 'bestie'
                      ? 'bg-white border-[#A64D79]/20 hover:border-[#A64D79]'
                      : 'bg-[#18243A] border-[#4A90E2]/30 hover:border-[#4A90E2]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={bill.isPaid}
                      onChange={() => {}} // handled by parent onClick
                      className="w-4 h-4 rounded text-emerald-600 cursor-pointer"
                    />
                    <div>
                      <div className="font-bold flex items-center gap-1.5">
                        <span>{bill.name}</span>
                        {bill.isPaid && (
                          <span className="text-[10px] no-underline font-normal text-emerald-600 bg-emerald-50 px-1.5 py-0.2 rounded">
                            Settled
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] opacity-70">
                        Due: {bill.dueDate} · Category: {bill.category}
                      </span>
                    </div>
                  </div>
                  <span className="font-mono font-bold text-sm">
                    {centsToCurrency(bill.amountCents)}
                  </span>
                </div>
              ))
            )}
          </div>

          {/* Essential Needs Reserves Summary */}
          <div className="border-t border-inherit pt-3 space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider opacity-75 block">
              Essential Spending Reserves (Food & Gas)
            </span>
            <div className="grid grid-cols-3 gap-2 text-xs">
              {profile.essentials.map((ess) => {
                const unspent = Math.max(0, ess.budgetedCents - ess.spentCents);
                return (
                  <div
                    key={ess.id}
                    className={`p-2 rounded-lg border text-center ${
                      mode === 'bestie' ? 'bg-[#FFF9F3] border-[#A64D79]/20' : 'bg-[#131D2E] border-[#4A90E2]/20'
                    }`}
                  >
                    <span className="text-[10px] opacity-75 font-semibold block truncate">
                      {ess.name}
                    </span>
                    <span className="font-mono font-bold text-xs block text-purple-600 dark:text-purple-400">
                      {centsToCurrency(unspent)}
                    </span>
                    <span className="text-[9px] opacity-50 block">reserved</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
