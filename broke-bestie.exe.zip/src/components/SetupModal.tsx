import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import { THEMES } from '../utils/theme';
import { Bill, EssentialCategory, PayFrequency } from '../types';
import { parseToCents, centsToCurrency } from '../utils/finance';
import { X, Plus, Trash2, Sparkles, Check, Calendar, DollarSign, ShieldCheck } from 'lucide-react';
import { sound } from '../utils/audio';

export const SetupModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => {
  const { mode, profile, updateProfile, setHasCompletedSetup, loadDemoData } = useGame();
  const theme = THEMES[mode];

  // Local form states
  const [bankBalance, setBankBalance] = useState<string>(
    profile.bankBalanceCents > 0 ? (profile.bankBalanceCents / 100).toFixed(2) : ''
  );
  const [cashBalance, setCashBalance] = useState<string>(
    profile.cashBalanceCents > 0 ? (profile.cashBalanceCents / 100).toFixed(2) : ''
  );
  const [expectedPaycheck, setExpectedPaycheck] = useState<string>(
    profile.expectedPaycheckCents > 0 ? (profile.expectedPaycheckCents / 100).toFixed(2) : ''
  );
  const [payFrequency, setPayFrequency] = useState<PayFrequency>(profile.payFrequency || 'biweekly');
  const [nextPaydayDate, setNextPaydayDate] = useState<string>(profile.nextPaydayDate);
  const [bills, setBills] = useState<Bill[]>(profile.bills);
  const [essentials, setEssentials] = useState<EssentialCategory[]>(profile.essentials);

  // New bill input states
  const [newBillName, setNewBillName] = useState('');
  const [newBillAmount, setNewBillAmount] = useState('');
  const [newBillDueDate, setNewBillDueDate] = useState(profile.nextPaydayDate);
  const [newBillCategory, setNewBillCategory] = useState<Bill['category']>('utilities');

  if (!isOpen) return null;

  const handleAddBill = () => {
    const amountCents = parseToCents(newBillAmount);
    if (!newBillName.trim() || amountCents <= 0) return;

    const newBill: Bill = {
      id: 'bill-' + Date.now(),
      name: newBillName.trim(),
      amountCents,
      dueDate: newBillDueDate || profile.nextPaydayDate,
      category: newBillCategory,
      isPaid: false,
    };
    setBills((prev) => [...prev, newBill]);
    setNewBillName('');
    setNewBillAmount('');
    sound.playBlip(640);
  };

  const handleRemoveBill = (id: string) => {
    setBills((prev) => prev.filter((b) => b.id !== id));
    sound.playBlip(300);
  };

  const handleUpdateEssential = (id: string, budgetedStr: string) => {
    const budgetedCents = parseToCents(budgetedStr);
    setEssentials((prev) =>
      prev.map((cat) => (cat.id === id ? { ...cat, budgetedCents } : cat))
    );
  };

  const handleSave = () => {
    const bankCents = parseToCents(bankBalance);
    const cashCents = parseToCents(cashBalance);
    const paycheckCents = parseToCents(expectedPaycheck);

    updateProfile((prev) => ({
      ...prev,
      bankBalanceCents: bankCents,
      cashBalanceCents: cashCents,
      expectedPaycheckCents: paycheckCents,
      payFrequency,
      nextPaydayDate: nextPaydayDate || prev.nextPaydayDate,
      bills,
      essentials,
    }));

    setHasCompletedSetup(true);
    sound.playCash();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div
        className={`w-full max-w-2xl rounded-2xl border-4 ${
          mode === 'bestie'
            ? 'bg-white border-[#A64D79] shadow-[8px_8px_0px_#A64D79]'
            : 'bg-[#18243A] border-[#4A90E2] shadow-[8px_8px_0px_#4A90E2] text-white'
        } my-8 overflow-hidden`}
      >
        {/* Modal Window Header */}
        <div
          className={`px-4 py-3 flex items-center justify-between border-b-2 ${
            mode === 'bestie'
              ? 'bg-[#F6D5E3] border-[#A64D79] text-[#A64D79]'
              : 'bg-[#20324E] border-[#4A90E2] text-[#8DD9B5]'
          }`}
        >
          <div className="flex items-center gap-2 font-pixel text-base sm:text-lg font-bold">
            <span>{mode === 'bestie' ? '🎀 BUDGET_SETUP.EXE' : '⚙️ SYSTEM_CONFIG.SYS'}</span>
            <span className="text-xs font-sans font-semibold opacity-80 hidden sm:inline">
              — {mode === 'bestie' ? 'Enter your money details' : 'Financial Profile Parameters'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                loadDemoData();
                onClose();
              }}
              className="px-2.5 py-1 text-xs font-bold rounded bg-emerald-500 hover:bg-emerald-600 text-white flex items-center gap-1 cursor-pointer"
              title="Quick populate with judge demo data"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Load Demo Data</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded hover:opacity-80 transition-opacity cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Section 1: Balances */}
          <div>
            <h3
              className={`text-sm font-bold uppercase tracking-wider mb-3 ${
                mode === 'bestie' ? 'text-[#A64D79]' : 'text-[#8DD9B5]'
              }`}
            >
              1. Current Wallet Balances
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold mb-1 opacity-90">
                  Bank / Card Balance ($)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs opacity-50 font-bold">$</span>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="e.g. 850.00"
                    value={bankBalance}
                    onChange={(e) => setBankBalance(e.target.value)}
                    className={`w-full pl-7 pr-3 py-2 rounded-lg text-sm font-mono ${theme.inputBg} ${theme.inputBorder}`}
                  />
                </div>
                <span className="text-[11px] opacity-60 mt-0.5 block">
                  Checking account or debit balance
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1 opacity-90">
                  Physical Cash in Hand ($)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs opacity-50 font-bold">$</span>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="e.g. 50.00"
                    value={cashBalance}
                    onChange={(e) => setCashBalance(e.target.value)}
                    className={`w-full pl-7 pr-3 py-2 rounded-lg text-sm font-mono ${theme.inputBg} ${theme.inputBorder}`}
                  />
                </div>
                <span className="text-[11px] opacity-60 mt-0.5 block">
                  Dollar bills or coins in your physical wallet
                </span>
              </div>
            </div>
          </div>

          {/* Section 2: Payday Timing */}
          <div className="border-t border-inherit pt-4">
            <h3
              className={`text-sm font-bold uppercase tracking-wider mb-3 ${
                mode === 'bestie' ? 'text-[#A64D79]' : 'text-[#8DD9B5]'
              }`}
            >
              2. Next Payday Schedule
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold mb-1 opacity-90">
                  Next Payday Date
                </label>
                <input
                  type="date"
                  value={nextPaydayDate}
                  onChange={(e) => setNextPaydayDate(e.target.value)}
                  className={`w-full px-3 py-2 rounded-lg text-sm ${theme.inputBg} ${theme.inputBorder}`}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1 opacity-90">
                  Pay Frequency
                </label>
                <select
                  value={payFrequency}
                  onChange={(e) => setPayFrequency(e.target.value as PayFrequency)}
                  className={`w-full px-3 py-2 rounded-lg text-sm ${theme.inputBg} ${theme.inputBorder}`}
                >
                  <option value="weekly">Weekly</option>
                  <option value="biweekly">Bi-weekly (Every 2 weeks)</option>
                  <option value="twice_monthly">Twice Monthly (1st & 15th)</option>
                  <option value="monthly">Monthly</option>
                  <option value="custom">Custom</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1 opacity-90">
                  Expected Paycheck ($) <span className="opacity-60">(Optional)</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs opacity-50 font-bold">$</span>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="e.g. 1500.00"
                    value={expectedPaycheck}
                    onChange={(e) => setExpectedPaycheck(e.target.value)}
                    className={`w-full pl-7 pr-3 py-2 rounded-lg text-sm font-mono ${theme.inputBg} ${theme.inputBorder}`}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Upcoming Bills */}
          <div className="border-t border-inherit pt-4">
            <div className="flex items-center justify-between mb-3">
              <h3
                className={`text-sm font-bold uppercase tracking-wider ${
                  mode === 'bestie' ? 'text-[#A64D79]' : 'text-[#8DD9B5]'
                }`}
              >
                3. Upcoming Bills (Before Next Payday)
              </h3>
              <span className="text-xs opacity-60">Reserved from your safe-to-spend</span>
            </div>

            {/* List of existing bills */}
            <div className="space-y-2 mb-3">
              {bills.length === 0 ? (
                <p className="text-xs opacity-60 italic py-2">No bills added yet for this pay period.</p>
              ) : (
                bills.map((bill) => (
                  <div
                    key={bill.id}
                    className={`p-2.5 rounded-lg flex items-center justify-between text-xs border ${
                      mode === 'bestie'
                        ? 'bg-[#FFF4E8]/60 border-[#A64D79]/20'
                        : 'bg-[#131D2E] border-[#4A90E2]/30'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-bold">{bill.name}</span>
                      <span className="opacity-70 text-[11px]">Due: {bill.dueDate}</span>
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-semibold ${
                          bill.isPaid ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {bill.isPaid ? 'Paid' : 'Unpaid'}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold">{centsToCurrency(bill.amountCents)}</span>
                      <button
                        onClick={() => handleRemoveBill(bill.id)}
                        className="text-red-500 hover:text-red-700 p-1 cursor-pointer"
                        title="Remove bill"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Add new bill inline */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
              <input
                type="text"
                placeholder="Bill title (e.g. Electric)"
                value={newBillName}
                onChange={(e) => setNewBillName(e.target.value)}
                className={`px-2.5 py-1.5 rounded ${theme.inputBg} ${theme.inputBorder}`}
              />
              <input
                type="number"
                step="0.01"
                placeholder="Amount ($)"
                value={newBillAmount}
                onChange={(e) => setNewBillAmount(e.target.value)}
                className={`px-2.5 py-1.5 rounded ${theme.inputBg} ${theme.inputBorder}`}
              />
              <input
                type="date"
                value={newBillDueDate}
                onChange={(e) => setNewBillDueDate(e.target.value)}
                className={`px-2.5 py-1.5 rounded ${theme.inputBg} ${theme.inputBorder}`}
              />
              <button
                type="button"
                onClick={handleAddBill}
                className={`px-3 py-1.5 rounded font-bold flex items-center justify-center gap-1 cursor-pointer ${theme.primaryButton}`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Bill</span>
              </button>
            </div>
          </div>

          {/* Section 4: Essential Expenses Reserves */}
          <div className="border-t border-inherit pt-4">
            <div className="flex items-center justify-between mb-2">
              <h3
                className={`text-sm font-bold uppercase tracking-wider ${
                  mode === 'bestie' ? 'text-[#A64D79]' : 'text-[#8DD9B5]'
                }`}
              >
                4. Essential Needs (Food, Gas, Meds)
              </h3>
              <span className="text-xs opacity-60">Estimated for remaining days</span>
            </div>
            <p className="text-xs opacity-70 mb-3">
              Lock in the cash you MUST have for food, gas, and transit so you don't accidentally blow it on iced matcha or shopping!
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {essentials.map((cat) => (
                <div
                  key={cat.id}
                  className={`p-3 rounded-lg border text-xs ${
                    mode === 'bestie'
                      ? 'bg-[#FFF9F3] border-[#A64D79]/20'
                      : 'bg-[#131D2E] border-[#4A90E2]/30'
                  }`}
                >
                  <label className="block font-bold mb-1">{cat.name}</label>
                  <div className="relative">
                    <span className="absolute left-2.5 top-2 opacity-50">$</span>
                    <input
                      type="number"
                      step="0.01"
                      defaultValue={(cat.budgetedCents / 100).toFixed(2)}
                      onBlur={(e) => handleUpdateEssential(cat.id, e.target.value)}
                      className={`w-full pl-6 pr-2 py-1.5 rounded font-mono ${theme.inputBg} ${theme.inputBorder}`}
                    />
                  </div>
                  <div className="flex justify-between items-center text-[11px] opacity-60 mt-1">
                    <span>Spent so far:</span>
                    <span className="font-mono">{centsToCurrency(cat.spentCents)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div
          className={`p-4 border-t-2 flex flex-col sm:flex-row items-center justify-between gap-3 ${
            mode === 'bestie' ? 'bg-[#FFF4E8] border-[#A64D79]/30' : 'bg-[#131D2E] border-[#4A90E2]/30'
          }`}
        >
          <button
            onClick={() => {
              loadDemoData();
              onClose();
            }}
            className="text-xs font-semibold text-slate-500 hover:text-slate-800 underline cursor-pointer"
          >
            Load Hackathon Demo Profile
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onClose}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold cursor-pointer ${theme.secondaryButton}`}
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className={`flex-1 sm:flex-none px-6 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${theme.primaryButton}`}
            >
              <Check className="w-4 h-4" />
              <span>Save & Calculate Survival</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
