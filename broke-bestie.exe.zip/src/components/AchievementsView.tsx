import React from 'react';
import { useGame } from '../context/GameContext';
import { THEMES } from '../utils/theme';
import {
  Trophy,
  Award,
  Sparkles,
  Heart,
  Crown,
  CheckCircle2,
  Lock,
  Flame,
  Zap,
  Shield,
  Coins,
  Smile,
} from 'lucide-react';

export const AchievementsView: React.FC = () => {
  const { mode, profile, metrics, achievements } = useGame();
  const theme = THEMES[mode];

  // Calculate game level based on unlocked badges and survival ratio
  const unlockedCount = achievements.filter((a) => a.unlocked).length;
  const levelNumber = Math.min(5, Math.max(1, Math.floor(unlockedCount / 1.5) + 1));

  const levelTitlesBestie = [
    'Level 1: Broke Era Survivor 🌱',
    'Level 2: Budgeting Cutie 🎀',
    'Level 3: Bill Boss Babe 💅',
    'Level 4: Glamour Solvency Queen 👑',
    'Level 5: Master of Coins & Payday Legend ✨',
  ];

  const levelTitlesClassic = [
    'Rank 1: Budget Rookie [RECON]',
    'Rank 2: Solvency Specialist [TACTICAL]',
    'Rank 3: Escrow Sentinel [VANGUARD]',
    'Rank 4: Liquidity Commander [ELITE]',
    'Rank 5: Payday Grandmaster [SYSTEM OVERLORD]',
  ];

  const currentLevelTitle =
    mode === 'bestie'
      ? levelTitlesBestie[levelNumber - 1]
      : levelTitlesClassic[levelNumber - 1];

  // Payday cycle progress percentage
  const cycleProgress = Math.max(
    0,
    Math.min(
      100,
      Math.round(((metrics.totalCycleDays - metrics.daysRemaining) / metrics.totalCycleDays) * 100)
    )
  );

  return (
    <div className="space-y-6">
      {/* Level Banner & Payday Journey Progress */}
      <div
        className={`p-6 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} relative overflow-hidden`}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div
              className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl border-3 shadow-md ${
                mode === 'bestie'
                  ? 'bg-[#F6D5E3] border-[#A64D79] text-[#A64D79]'
                  : 'bg-[#20324E] border-[#4A90E2] text-[#8DD9B5]'
              }`}
            >
              {mode === 'bestie' ? '👑' : '🏆'}
            </div>
            <div>
              <span className="text-xs uppercase font-bold tracking-wider opacity-70 block">
                {mode === 'bestie' ? 'Player Progression Level' : 'Tactical Rank & Standing'}
              </span>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight">{currentLevelTitle}</h2>
              <p className="text-xs opacity-75 mt-0.5">
                {unlockedCount} of {achievements.length} badges unlocked this cycle
              </p>
            </div>
          </div>

          <div
            className={`p-3 rounded-xl border text-xs text-center shrink-0 ${
              mode === 'bestie' ? 'bg-[#FFF9F3] border-[#A64D79]/20' : 'bg-[#18243A] border-[#4A90E2]/30'
            }`}
          >
            <span className="opacity-70 text-[10px] uppercase font-bold block">Next Check Lands</span>
            <span className="font-mono text-base font-black text-amber-500 block">
              {metrics.daysRemaining} days left
            </span>
            <span className="text-[10px] opacity-60">Cycle Day {metrics.cycleDayNumber} of {metrics.totalCycleDays}</span>
          </div>
        </div>

        {/* Payday Cycle Progress Meter */}
        <div className="mt-6 pt-4 border-t border-inherit">
          <div className="flex justify-between items-center text-xs font-bold mb-1.5">
            <span>Payday Level Journey: {cycleProgress}% Completed</span>
            <span className="font-mono">{metrics.daysRemaining} days remaining</span>
          </div>
          <div className="w-full h-4 rounded-full bg-slate-200 dark:bg-slate-800 p-0.5 border border-slate-300 dark:border-slate-700 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                mode === 'bestie'
                  ? 'bg-gradient-to-r from-pink-400 to-rose-500'
                  : 'bg-gradient-to-r from-blue-500 to-emerald-400'
              }`}
              style={{ width: `${Math.max(5, cycleProgress)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Badges Grid */}
      <div
        className={`p-6 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} space-y-4`}
      >
        <div className="flex items-center justify-between border-b border-inherit pb-3">
          <div>
            <h3 className="font-black text-base uppercase tracking-tight">
              {mode === 'bestie' ? 'Virtual Trophy Cabinet 🏆' : 'Achievement Badges 🎖️'}
            </h3>
            <p className="text-xs opacity-75">
              Virtual rewards earned by practicing mindful money habits and avoiding traps.
            </p>
          </div>
          <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 border border-emerald-300">
            {unlockedCount} / {achievements.length} Unlocked
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {achievements.map((item) => {
            const title = mode === 'bestie' ? item.titleBestie : item.titleClassic;
            const desc = mode === 'bestie' ? item.descBestie : item.descClassic;

            return (
              <div
                key={item.id}
                className={`p-4 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                  item.unlocked
                    ? mode === 'bestie'
                      ? 'bg-gradient-to-br from-white to-[#F6D5E3]/40 border-[#A64D79]/40 shadow-[3px_3px_0px_#A64D79]'
                      : 'bg-gradient-to-br from-[#18243A] to-[#20324E] border-[#4A90E2]/50 shadow-[3px_3px_0px_#4A90E2]'
                    : 'opacity-50 grayscale border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl">
                      {item.unlocked ? (mode === 'bestie' ? '💖' : '🎖️') : '🔒'}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        item.unlocked
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
                      }`}
                    >
                      {item.unlocked ? 'Unlocked' : 'In Progress'}
                    </span>
                  </div>

                  <h4 className="font-black text-sm mb-1">{title}</h4>
                  <p className="text-xs opacity-75 leading-relaxed">{desc}</p>
                </div>

                {item.unlocked && item.unlockedAt && (
                  <div className="pt-3 mt-3 border-t border-inherit text-[10px] opacity-60 font-mono">
                    Unlocked: {new Date(item.unlockedAt).toLocaleDateString()}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
