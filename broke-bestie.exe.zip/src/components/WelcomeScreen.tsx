import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import { AppMode } from '../types';
import { Heart, Gamepad2, Sparkles, ArrowRight, Play, ShieldAlert, Award, Zap } from 'lucide-react';
import { sound } from '../utils/audio';

export const WelcomeScreen: React.FC<{ onStartSetup: () => void }> = ({ onStartSetup }) => {
  const { setMode, loadDemoData, setHasCompletedSetup } = useGame();
  const [hasStarted, setHasStarted] = useState(false);

  const handleSelectMode = (selectedMode: AppMode) => {
    setMode(selectedMode);
    sound.playLevelUp();
    onStartSetup();
  };

  const handleInstantDemo = (selectedMode: AppMode) => {
    setMode(selectedMode);
    loadDemoData();
    setHasCompletedSetup(true);
  };

  return (
    <div className="min-h-screen bg-[#FFF4E8] flex items-center justify-center p-4 relative overflow-hidden font-sans">
      {/* Retro Grid Background */}
      <div
        className="absolute inset-0 pointer-events-none opacity-25"
        style={{
          backgroundImage: 'linear-gradient(#A64D79 1px, transparent 1px), linear-gradient(90deg, #A64D79 1px, transparent 1px)',
          backgroundSize: '32px 32px',
        }}
      />

      {/* Main Y2K Window Container */}
      <div className="relative z-10 w-full max-w-4xl bg-white border-4 border-[#A64D79] rounded-xl shadow-[8px_8px_0px_0px_#A64D79] overflow-hidden">
        {/* Retro Window Titlebar */}
        <div className="bg-gradient-to-r from-[#F6D5E3] via-[#E8DDF5] to-[#F6D5E3] border-b-4 border-[#A64D79] px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded-full bg-[#D94B65] border border-[#541c38] inline-block" />
            <span className="w-3.5 h-3.5 rounded-full bg-[#F6D5E3] border border-[#541c38] inline-block" />
            <span className="w-3.5 h-3.5 rounded-full bg-[#8DD9B5] border border-[#541c38] inline-block" />
            <span className="ml-2 font-pixel text-lg text-[#A64D79] font-bold tracking-wider">
              BROKE_BESTIE.EXE [VER 1.0-STABLE]
            </span>
          </div>
          <div className="font-pixel text-xs text-[#A64D79] font-bold">READY TO PLAY</div>
        </div>

        {/* Content Body */}
        <div className="p-6 md:p-8">
          {!hasStarted ? (
            /* Phase 1: Title Screen & Start Game */
            <div className="flex flex-col items-center text-center space-y-6">
              {/* Retro Hero Image Banner */}
              <div className="w-full max-h-72 rounded-lg border-2 border-[#A64D79]/40 overflow-hidden shadow-inner relative group">
                <img
                  src="/src/assets/images/broke_bestie_cover_1792259485130.jpg"
                  alt="Broke Bestie Retro Arcade Banner"
                  referrerPolicy="no-referrer"
                  className="w-full h-56 md:h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-4">
                  <div className="text-left text-white">
                    <span className="font-pixel text-xs bg-[#A64D79] px-2 py-0.5 rounded uppercase tracking-wider text-white">
                      Y2K Financial Survival Engine
                    </span>
                    <p className="text-sm font-medium text-pink-100">
                      Real money tracking meets nostalgic gaming excitement
                    </p>
                  </div>
                </div>
              </div>

              {/* Title & Tagline */}
              <div className="space-y-2">
                <h1 className="text-4xl sm:text-5xl md:text-6xl font-black text-[#A64D79] tracking-tight">
                  BROKE BESTIE<span className="font-pixel text-3xl sm:text-4xl text-[#D94B65]">.EXE</span>
                </h1>
                <p className="text-lg sm:text-xl font-bold text-[#541c38] italic">
                  "Survive payday, one questionable purchase at a time."
                </p>
                <p className="max-w-xl mx-auto text-sm text-slate-600 mt-2">
                  Find out if your wallet will survive until next payday. Tracks real bank funds, physical cash,
                  locked bill reserves, and gives you an honest daily spending allowance with retro flair.
                </p>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full max-w-md pt-2">
                <button
                  onClick={() => {
                    sound.playBlip(600);
                    setHasStarted(true);
                  }}
                  className="w-full sm:w-auto flex-1 px-8 py-3.5 bg-[#A64D79] hover:bg-[#8e3f65] text-white font-extrabold text-lg rounded-xl border-2 border-[#541c38] shadow-[4px_4px_0px_#541c38] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Play className="w-5 h-5 fill-white" />
                  <span>START GAME</span>
                </button>

                <button
                  onClick={() => handleInstantDemo('bestie')}
                  className="w-full sm:w-auto px-6 py-3.5 bg-[#FFF4E8] hover:bg-[#faebd9] text-[#A64D79] font-bold text-sm rounded-xl border-2 border-[#A64D79] shadow-[3px_3px_0px_#A64D79] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  title="Load pre-configured demo budget for instant live testing"
                >
                  <Sparkles className="w-4 h-4 text-[#D94B65]" />
                  <span>Try Demo Mode (Instant Play)</span>
                </button>
              </div>

              {/* Quick Feature highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full text-left pt-4 border-t border-slate-200">
                <div className="p-3 bg-[#FFF4E8] rounded-lg border border-[#A64D79]/20">
                  <div className="font-bold text-xs text-[#A64D79] flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5 text-[#D94B65]" />
                    <span>Safe-to-Spend Math</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Automatically subtracts unpaid bills and groceries so you never get caught short.
                  </p>
                </div>
                <div className="p-3 bg-[#FFF4E8] rounded-lg border border-[#A64D79]/20">
                  <div className="font-bold text-xs text-[#A64D79] flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#A64D79]" />
                    <span>Delulu Checker</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Simulate before buying. See if an impulse item pushes your wallet into crisis era.
                  </p>
                </div>
                <div className="p-3 bg-[#FFF4E8] rounded-lg border border-[#A64D79]/20">
                  <div className="font-bold text-xs text-[#A64D79] flex items-center gap-1">
                    <Award className="w-3.5 h-3.5 text-blue-600" />
                    <span>Two Styled Modes</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Switch freely between cute Y2K Bestie Mode or arcade-styled Classic Mode anytime.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            /* Phase 2: Mode Selection */
            <div className="space-y-6 text-center animate-fadeIn">
              <div>
                <h2 className="text-2xl sm:text-3xl font-black text-[#A64D79]">
                  SELECT YOUR GAMEPLAY MODE
                </h2>
                <p className="text-slate-600 text-sm mt-1">
                  Choose your visual aesthetic and personality preference. Both modes use the exact same financial
                  calculations and you can switch back and forth anytime!
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                {/* BESTIE MODE CARD */}
                <div className="group relative bg-[#FFF4E8] hover:bg-[#ffeedd] border-3 border-[#A64D79] rounded-2xl p-6 shadow-[5px_5px_0px_0px_#A64D79] transition-all flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-10 h-10 rounded-xl bg-[#F6D5E3] border-2 border-[#A64D79] flex items-center justify-center text-xl shadow-[2px_2px_0px_#A64D79]">
                          💗
                        </div>
                        <div>
                          <h3 className="text-xl font-black text-[#A64D79]">BESTIE MODE</h3>
                          <span className="text-xs font-semibold text-[#D94B65]">"Budgeting, but make it cute."</span>
                        </div>
                      </div>
                      <span className="text-xs font-bold font-pixel bg-[#F6D5E3] text-[#A64D79] px-2 py-0.5 rounded border border-[#A64D79]/30">
                        Y2K VIBES
                      </span>
                    </div>

                    <p className="text-xs text-slate-700 leading-relaxed mb-4">
                      Baby pinks, berry tones, retro computer windows, Girl Math breakdowns, pixel hearts, and playful
                      motivational commentary to keep financial stress away.
                    </p>

                    <div className="space-y-2 text-xs font-semibold text-[#A64D79] bg-white/80 p-3 rounded-lg border border-[#A64D79]/20">
                      <div className="flex items-center gap-1.5">
                        <Heart className="w-3.5 h-3.5 text-[#D94B65] fill-[#D94B65]" />
                        <span>Girl Math.exe interactive calculator</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-[#A64D79]" />
                        <span>"Delulu or Responsible?" purchase verifier</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Award className="w-3.5 h-3.5 text-pink-500" />
                        <span>Cute hearts, bows, and star badges</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 flex flex-col sm:flex-row gap-2">
                    <button
                      onClick={() => handleSelectMode('bestie')}
                      className="flex-1 px-4 py-2.5 bg-[#A64D79] hover:bg-[#8e3f65] text-white font-bold text-sm rounded-xl border-2 border-[#541c38] shadow-[3px_3px_0px_#541c38] flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>Choose Bestie Mode</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleInstantDemo('bestie')}
                      className="px-3 py-2.5 bg-[#F6D5E3] hover:bg-[#ebd0dd] text-[#A64D79] font-bold text-xs rounded-xl border border-[#A64D79]/40 cursor-pointer whitespace-nowrap"
                      title="Load demo data in Bestie Mode"
                    >
                      Demo
                    </button>
                  </div>
                </div>

                {/* CLASSIC MODE CARD */}
                <div className="group relative bg-[#18243A] hover:bg-[#1d2c47] border-3 border-[#4A90E2] rounded-2xl p-6 shadow-[5px_5px_0px_0px_#4A90E2] text-white transition-all flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-10 h-10 rounded-xl bg-[#20324E] border-2 border-[#4A90E2] flex items-center justify-center text-xl shadow-[2px_2px_0px_#4A90E2]">
                          🎮
                        </div>
                        <div>
                          <h3 className="text-xl font-black text-[#8DD9B5]">CLASSIC MODE</h3>
                          <span className="text-xs font-semibold text-[#4A90E2]">"Beat the budget. Reach payday."</span>
                        </div>
                      </div>
                      <span className="text-xs font-bold font-pixel bg-[#20324E] text-[#8DD9B5] px-2 py-0.5 rounded border border-[#4A90E2]/40">
                        RETRO ARCADE
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed mb-4">
                      Midnight navy and electric blue palette, pixel progress bars, arcade HUD telemetry, Money Myths vs
                      Money Facts, and digital survival level challenges.
                    </p>

                    <div className="space-y-2 text-xs font-semibold text-[#8DD9B5] bg-[#131D2E] p-3 rounded-lg border border-[#4A90E2]/30">
                      <div className="flex items-center gap-1.5">
                        <Gamepad2 className="w-3.5 h-3.5 text-[#4A90E2]" />
                        <span>Money Myths vs Money Facts simulator</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5 text-amber-400" />
                        <span>System Purchase Risk Evaluator</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Award className="w-3.5 h-3.5 text-[#8DD9B5]" />
                        <span>Arcade achievement trophies & rank badges</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 flex flex-col sm:flex-row gap-2">
                    <button
                      onClick={() => handleSelectMode('classic')}
                      className="flex-1 px-4 py-2.5 bg-[#4A90E2] hover:bg-[#3b7dc7] text-white font-bold text-sm rounded-xl border-2 border-[#18243A] shadow-[3px_3px_0px_#18243A] flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>Choose Classic Mode</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleInstantDemo('classic')}
                      className="px-3 py-2.5 bg-[#20324E] hover:bg-[#283e61] text-[#8DD9B5] font-bold text-xs rounded-xl border border-[#4A90E2]/40 cursor-pointer whitespace-nowrap"
                      title="Load demo data in Classic Mode"
                    >
                      Demo
                    </button>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={() => setHasStarted(false)}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 underline cursor-pointer"
                >
                  ← Back to Title Screen
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
