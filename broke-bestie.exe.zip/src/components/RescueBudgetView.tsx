import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import { THEMES } from '../utils/theme';
import { centsToCurrency } from '../utils/finance';
import {
  ShieldAlert,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  Heart,
  TrendingUp,
  Receipt,
  RotateCcw,
  Coffee,
  Utensils,
  Tv,
  Coins,
} from 'lucide-react';
import { sound } from '../utils/audio';

interface RescueStrategy {
  id: string;
  title: string;
  savingsCents: number;
  icon: string;
  category: 'cut' | 'pantry' | 'boost';
  description: string;
}

const DEFAULT_STRATEGIES: RescueStrategy[] = [
  {
    id: 'pantry_chef',
    title: 'Pantry & Freezer Cooking Challenge',
    savingsCents: 4500, // $45.00
    icon: 'Utensils',
    category: 'pantry',
    description: 'Use the rice, pasta, canned goods, and frozen meals already in your kitchen instead of DoorDash or groceries.',
  },
  {
    id: 'homebrew_coffee',
    title: 'Homebrew Matcha / Coffee Only',
    savingsCents: 2400, // $24.00
    icon: 'Coffee',
    category: 'cut',
    description: 'Skip coffee shop visits until payday. Brew beans or tea at home (saves ~$6/day for 4 days).',
  },
  {
    id: 'pause_subscriptions',
    title: 'Pause Non-Essential Subscriptions',
    savingsCents: 1600, // $16.00
    icon: 'Tv',
    category: 'cut',
    description: 'Temporarily pause entertainment streaming or gym passes set to renew before your paycheck lands.',
  },
  {
    id: 'marketplace_declutter',
    title: 'Quick Closet / Gear Sale',
    savingsCents: 5000, // $50.00
    icon: 'Coins',
    category: 'boost',
    description: 'Sell a pair of shoes, vintage jacket, or unused electronics on Facebook Marketplace or Poshmark for instant cash.',
  },
];

export const RescueBudgetView: React.FC = () => {
  const { mode, profile, metrics, addTransaction } = useGame();
  const theme = THEMES[mode];

  // Active simulated strategies
  const [selectedStrategyIds, setSelectedStrategyIds] = useState<string[]>([]);
  const [appliedNotification, setAppliedNotification] = useState<string | null>(null);

  const toggleStrategy = (id: string) => {
    setSelectedStrategyIds((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    );
    sound.playBlip(560);
  };

  // Compute simulated rescue recovery
  const simulatedSavingsCents = DEFAULT_STRATEGIES.filter((s) =>
    selectedStrategyIds.includes(s.id)
  ).reduce((acc, s) => acc + s.savingsCents, 0);

  const simSafeToSpend = metrics.safeToSpendCents + simulatedSavingsCents;
  const simShortfall = simSafeToSpend < 0 ? Math.abs(simSafeToSpend) : 0;
  const simDaily = simSafeToSpend > 0 ? Math.floor(simSafeToSpend / metrics.daysRemaining) : 0;

  const handleApplyBoostAsIncome = (strategy: RescueStrategy) => {
    const res = addTransaction({
      description: strategy.title + ' (Rescue Action)',
      amountCents: strategy.savingsCents,
      type: 'income',
      paymentMethod: 'cash',
      date: new Date().toISOString(),
      category: 'Rescue Recovery',
    });

    if (res.success) {
      sound.playLevelUp();
      setAppliedNotification(`Deposited ${centsToCurrency(strategy.savingsCents)} cash to your wallet!`);
      // unselect from simulator
      setSelectedStrategyIds((prev) => prev.filter((id) => id !== strategy.id));
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Rally Header */}
      <div
        className={`p-6 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} relative overflow-hidden`}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div
              className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl border-2 shrink-0 ${
                mode === 'bestie'
                  ? 'bg-[#F6D5E3] border-[#A64D79] text-[#A64D79]'
                  : 'bg-[#20324E] border-[#4A90E2] text-[#8DD9B5]'
              }`}
            >
              {mode === 'bestie' ? '💖' : '🛡️'}
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight">
                {mode === 'bestie'
                  ? "Bestie, We're Not Panicking. We're Making a Comeback! 💅"
                  : 'Recovery Mode Activated: Spending Plan Rebuild 🛡️'}
              </h2>
              <p className="text-xs opacity-80 mt-1 max-w-xl">
                {mode === 'bestie'
                  ? 'Life happens, but payday is only a few days away. Here is our step-by-step game plan to protect your bills and get you across the finish line!'
                  : 'System recovery algorithm engaged. Stabilize cashflow variance through targeted expenditure mitigation.'}
              </p>
            </div>
          </div>

          <div
            className={`p-3 rounded-xl border text-xs text-center shrink-0 ${
              metrics.shortfallCents > 0
                ? 'bg-rose-100 dark:bg-rose-950/60 border-rose-400 text-rose-800 dark:text-rose-200'
                : 'bg-emerald-100 dark:bg-emerald-950/60 border-emerald-400 text-emerald-800 dark:text-emerald-200'
            }`}
          >
            <span className="text-[10px] uppercase font-bold block">Current Gap / Margin</span>
            <span className="font-mono text-lg font-black block">
              {metrics.shortfallCents > 0
                ? `-${centsToCurrency(metrics.shortfallCents)} Shortfall`
                : `+${centsToCurrency(metrics.safeToSpendCents)} Safe Buffer`}
            </span>
            <span className="text-[10px] opacity-75">{metrics.daysRemaining} days to bridge</span>
          </div>
        </div>
      </div>

      {appliedNotification && (
        <div className="p-3 bg-emerald-100 text-emerald-900 border border-emerald-400 rounded-xl text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{appliedNotification}</span>
        </div>
      )}

      {/* Breakdown: Remaining Money vs Obligations */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div
          className={`p-4 rounded-xl border-2 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow}`}
        >
          <span className="text-xs font-bold uppercase tracking-wider opacity-70 block mb-1">
            Total Available Funds
          </span>
          <span className="font-mono text-2xl font-black block">
            {centsToCurrency(metrics.totalFundsCents)}
          </span>
          <div className="text-[11px] opacity-60 mt-2 space-y-0.5">
            <div>Bank Balance: {centsToCurrency(metrics.bankBalanceCents)}</div>
            <div>Cash in Pocket: {centsToCurrency(metrics.cashBalanceCents)}</div>
          </div>
        </div>

        <div
          className={`p-4 rounded-xl border-2 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow}`}
        >
          <span className="text-xs font-bold uppercase tracking-wider opacity-70 block mb-1">
            Must-Cover Obligations 🔒
          </span>
          <span className="font-mono text-2xl font-black text-purple-600 dark:text-purple-400 block">
            {centsToCurrency(metrics.reservedFundsCents)}
          </span>
          <div className="text-[11px] opacity-60 mt-2 space-y-0.5">
            <div>Unpaid Bills: {centsToCurrency(metrics.unpaidBillsCents)}</div>
            <div>Remaining Food/Gas: {centsToCurrency(metrics.remainingEssentialsCents)}</div>
          </div>
        </div>

        <div
          className={`p-4 rounded-xl border-2 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow}`}
        >
          <span className="text-xs font-bold uppercase tracking-wider opacity-70 block mb-1">
            Discretionary Allowance
          </span>
          <span
            className={`font-mono text-2xl font-black block ${
              metrics.safeToSpendCents < 0 ? 'text-red-500' : 'text-blue-500'
            }`}
          >
            {metrics.safeToSpendCents < 0
              ? `Shortfall of ${centsToCurrency(metrics.shortfallCents)}`
              : `${centsToCurrency(metrics.dailyAllowanceCents)} / day`}
          </span>
          <div className="text-[11px] opacity-60 mt-2">
            Divided over {metrics.daysRemaining} days remaining in cycle
          </div>
        </div>
      </div>

      {/* Interactive Rescue Comeback Simulator */}
      <div
        className={`p-6 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} space-y-5`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-inherit pb-3">
          <div>
            <h3 className="font-black text-base uppercase tracking-tight flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-amber-500" />
              <span>Interactive Recovery Action Menu</span>
            </h3>
            <p className="text-xs opacity-75">
              Select strategies below to simulate how quickly your budget returns to safety:
            </p>
          </div>

          {selectedStrategyIds.length > 0 && (
            <button
              onClick={() => setSelectedStrategyIds([])}
              className="text-xs font-bold opacity-60 hover:opacity-100 underline cursor-pointer"
            >
              Reset Simulation
            </button>
          )}
        </div>

        {/* Strategy cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {DEFAULT_STRATEGIES.map((strat) => {
            const isSelected = selectedStrategyIds.includes(strat.id);
            return (
              <div
                key={strat.id}
                onClick={() => toggleStrategy(strat.id)}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                  isSelected
                    ? mode === 'bestie'
                      ? 'bg-[#F6D5E3] border-[#A64D79] shadow-[3px_3px_0px_#A64D79]'
                      : 'bg-[#20324E] border-[#4A90E2] shadow-[3px_3px_0px_#4A90E2]'
                    : `${theme.cardBg} ${theme.cardBorder} opacity-80 hover:opacity-100`
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-xs sm:text-sm">{strat.title}</span>
                    <span className="font-mono font-black text-emerald-600 dark:text-emerald-400 text-xs">
                      +{centsToCurrency(strat.savingsCents)}
                    </span>
                  </div>
                  <p className="text-[11px] opacity-75 leading-relaxed">{strat.description}</p>
                </div>

                <div className="flex items-center justify-between pt-3 mt-2 border-t border-inherit">
                  <span className="text-[10px] uppercase font-bold opacity-70">
                    {isSelected ? '✓ Active in Simulator' : '+ Click to Simulate'}
                  </span>
                  {strat.category === 'boost' && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleApplyBoostAsIncome(strat);
                      }}
                      className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-600 text-white hover:bg-emerald-700 cursor-pointer"
                      title="Log as real completed side cash"
                    >
                      Log as Real Cash Deposit 💵
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Live Simulated Result Banner */}
        <div
          className={`p-4 rounded-xl border-2 ${
            simSafeToSpend >= 0
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-200'
              : 'bg-amber-50 dark:bg-amber-950/40 border-amber-500 text-amber-900 dark:text-amber-200'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider block">
                Simulated Recovery Impact
              </span>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="font-mono text-xl sm:text-2xl font-black">
                  {simSafeToSpend >= 0
                    ? `Safe-to-Spend: +${centsToCurrency(simSafeToSpend)}`
                    : `Remaining Shortfall: -${centsToCurrency(simShortfall)}`}
                </span>
                <span className="text-xs opacity-75 font-mono">
                  ({centsToCurrency(simDaily)}/day)
                </span>
              </div>
              <p className="text-xs opacity-80 mt-1">
                {simSafeToSpend >= 0
                  ? '🎉 Comeback Complete! These steps successfully rescue your budget and keep bills safe!'
                  : 'Getting closer! Pick an additional step or defer one more optional item to clear the shortfall.'}
              </p>
            </div>

            <div className="font-mono text-xs font-bold px-3 py-1.5 rounded-lg bg-white/70 dark:bg-black/40 border border-inherit shrink-0">
              +{centsToCurrency(simulatedSavingsCents)} total saved
            </div>
          </div>
        </div>
      </div>

      {/* Ethical Financial Guidance Note */}
      <div
        className={`p-4 rounded-xl border text-xs opacity-80 ${
          mode === 'bestie' ? 'bg-[#FFF9F3] border-[#A64D79]/20' : 'bg-[#18243A] border-[#4A90E2]/30'
        }`}
      >
        <span className="font-bold">Core Financial Principle: </span>
        Never skip critical medication, mandatory rent, or essential safety needs to "game" a budget score.
        Broke Bestie helps prioritize non-negotiable survival obligations first so you stay in control.
      </div>
    </div>
  );
};
