import React from 'react';
import { useGame } from '../context/GameContext';
import { THEMES } from '../utils/theme';
import { centsToCurrency } from '../utils/finance';
import { ShieldAlert, Heart, Shield, AlertTriangle, Sparkles, Zap } from 'lucide-react';

export const WalletHealthBar: React.FC<{ onOpenRescue: () => void }> = ({ onOpenRescue }) => {
  const { mode, metrics } = useGame();
  const theme = THEMES[mode];

  const { healthStatus, healthScorePercent, safeToSpendCents, shortfallCents, dailyAllowanceCents } = metrics;

  // Determine bar colors and messaging
  let barGradient = 'from-emerald-400 to-green-500';
  let badgeBg = 'bg-emerald-100 text-emerald-800 border-emerald-300';
  let statusText = mode === 'bestie' ? 'THRIVING BESTIE 💅' : 'SOLVENCY NOMINAL 🟢';
  let statusDesc = mode === 'bestie'
    ? 'All bills and groceries are covered! You have safe spending money.'
    : 'All obligations locked. Discretionary reserves within safe operating tolerances.';

  if (healthStatus === 'yellow') {
    barGradient = 'from-amber-400 to-yellow-500';
    badgeBg = 'bg-amber-100 text-amber-800 border-amber-300';
    statusText = mode === 'bestie' ? 'WATCH IT BESTIE ⚠️' : 'CAUTION: TIGHT MARGINS 🟡';
    statusDesc = mode === 'bestie'
      ? 'Discretionary funds are getting low. Think twice before splurging!'
      : 'Discretionary buffer under 20% threshold. Minimize non-essential burn rate.';
  } else if (healthStatus === 'red') {
    barGradient = 'from-rose-500 to-red-600';
    badgeBg = 'bg-rose-100 text-rose-800 border-rose-300 animate-pulse';
    statusText = mode === 'bestie' ? 'BROKE ERA ALERT 🚨' : 'CRITICAL DEFICIT 🔴';
    statusDesc = mode === 'bestie'
      ? `Shortfall of ${centsToCurrency(shortfallCents)}! Upcoming bills or groceries are at risk!`
      : `Obligations exceed total liquidity by ${centsToCurrency(shortfallCents)}. Escrow endangered.`;
  }

  return (
    <div
      className={`p-4 sm:p-5 rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} ${theme.cardShadow} relative overflow-hidden`}
    >
      {/* Top row: Status header & rescue shortcut */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <div className="flex items-center">
            {mode === 'bestie' ? (
              <span className="text-xl">
                {healthStatus === 'green' ? '💖' : healthStatus === 'yellow' ? '💛' : '💔'}
              </span>
            ) : (
              <span className="text-xl">
                {healthStatus === 'green' ? '🛡️' : healthStatus === 'yellow' ? '⚡' : '🚨'}
              </span>
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-black tracking-tight uppercase">
                {mode === 'bestie' ? 'Wallet Health Meter' : 'Payday Survival Matrix'}
              </h2>
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${badgeBg}`}>
                {statusText}
              </span>
            </div>
            <p className="text-xs opacity-75 mt-0.5">{statusDesc}</p>
          </div>
        </div>

        {healthStatus !== 'green' && (
          <button
            onClick={onOpenRescue}
            className={`self-start sm:self-auto px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              healthStatus === 'red'
                ? 'bg-red-600 hover:bg-red-700 text-white shadow-[2px_2px_0px_#991b1b]'
                : theme.secondaryButton
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>{mode === 'bestie' ? 'Rescue My Budget 🆘' : 'Execute Recovery 🛡️'}</span>
          </button>
        )}
      </div>

      {/* The Animated Health Bar */}
      <div className="relative my-2">
        <div className="w-full h-7 rounded-xl bg-slate-200 dark:bg-slate-800 p-1 border-2 border-slate-300 dark:border-slate-700 overflow-hidden relative shadow-inner">
          {/* Fill Bar */}
          <div
            className={`h-full rounded-lg bg-gradient-to-r ${barGradient} transition-all duration-700 ease-out flex items-center justify-end pr-2`}
            style={{ width: `${Math.max(6, Math.min(100, healthScorePercent))}%` }}
          >
            {/* Gloss highlight */}
            <div className="absolute inset-0 bg-white/20 pointer-events-none rounded-lg" />
          </div>
        </div>

        {/* Health Score Label */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-xs font-mono font-black drop-shadow">
          <span className="text-slate-900 dark:text-white bg-white/70 dark:bg-black/70 px-2 py-0.5 rounded border border-black/10">
            {healthScorePercent}% SURVIVAL INTEGRITY
          </span>
        </div>
      </div>

      {/* Metrics Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-xs">
        <div className={`p-2 rounded-lg border ${theme.statBoxBg} ${theme.statBoxBorder}`}>
          <span className="opacity-70 text-[10px] uppercase font-bold block">Safe to Spend</span>
          <span
            className={`font-mono text-sm sm:text-base font-black ${
              safeToSpendCents < 0 ? 'text-red-500' : 'text-emerald-600 dark:text-emerald-400'
            }`}
          >
            {centsToCurrency(safeToSpendCents)}
          </span>
        </div>

        <div className={`p-2 rounded-lg border ${theme.statBoxBg} ${theme.statBoxBorder}`}>
          <span className="opacity-70 text-[10px] uppercase font-bold block">Daily Allowance</span>
          <span className="font-mono text-sm sm:text-base font-black text-blue-600 dark:text-blue-400">
            {centsToCurrency(dailyAllowanceCents)} <span className="text-[10px] font-normal">/ day</span>
          </span>
        </div>

        <div className={`p-2 rounded-lg border ${theme.statBoxBg} ${theme.statBoxBorder}`}>
          <span className="opacity-70 text-[10px] uppercase font-bold block">Days to Payday</span>
          <span className="font-mono text-sm sm:text-base font-black text-amber-600 dark:text-amber-400">
            {metrics.daysRemaining} {metrics.daysRemaining === 1 ? 'day' : 'days'}
          </span>
        </div>

        <div className={`p-2 rounded-lg border ${theme.statBoxBg} ${theme.statBoxBorder}`}>
          <span className="opacity-70 text-[10px] uppercase font-bold block">
            {safeToSpendCents < 0 ? 'Shortfall' : 'Locked Reserves'}
          </span>
          <span
            className={`font-mono text-sm sm:text-base font-black ${
              safeToSpendCents < 0 ? 'text-rose-600' : 'text-purple-600 dark:text-purple-400'
            }`}
          >
            {safeToSpendCents < 0
              ? centsToCurrency(shortfallCents)
              : centsToCurrency(metrics.reservedFundsCents)}
          </span>
        </div>
      </div>
    </div>
  );
};
