import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import { THEMES } from '../utils/theme';
import { MessageSquare, X, ChevronRight, Sparkles, Volume2 } from 'lucide-react';
import { sound } from '../utils/audio';

export const AssistantWidget: React.FC = () => {
  const { mode, metrics, profile } = useGame();
  const theme = THEMES[mode];

  const [isMinimized, setIsMinimized] = useState(false);
  const [speechIndex, setSpeechIndex] = useState(0);

  // Dynamic rule-based dialogue based on real state
  const bestiePhrases: string[] = [];
  const classicPhrases: string[] = [];

  if (metrics.healthStatus === 'red') {
    bestiePhrases.push('Girl, the math isn’t mathing! Our wallet is in code red!');
    bestiePhrases.push('Bestie, pause the online cart! We have upcoming bills that need this money.');
    classicPhrases.push('CRITICAL: Budget warning detected! Escrow deficit impending.');
    classicPhrases.push('Immediate mitigation advised: divert liquidity to scheduled obligations.');
  } else if (metrics.healthStatus === 'yellow') {
    bestiePhrases.push('Bestie, watch out! Discretionary cash is getting a little tight.');
    bestiePhrases.push('Your wallet needs a little TLC before Friday!');
    classicPhrases.push('ALERT: Discretionary margin operating at sub-optimal levels.');
    classicPhrases.push('Recommendation: hold non-essential authorizations until cycle reset.');
  } else {
    bestiePhrases.push('You’re doing amazing bestie! Everything is covered and safe!');
    bestiePhrases.push('Look at you managing your cash like a total boss babe! 💅');
    classicPhrases.push('Systems nominal. Solvency trajectory fully synchronized.');
    classicPhrases.push('Excellent discipline, Commander. Payday endpoint in sight.');
  }

  // Payday proximity phrases
  if (metrics.daysRemaining <= 2) {
    bestiePhrases.push('OMG you made it to payday! Period! 🎉');
    classicPhrases.push('Payday rendezvous imminent. Level completion guaranteed.');
  } else {
    bestiePhrases.push(`${metrics.daysRemaining} days left! We can totally conquer this stretch.`);
    classicPhrases.push(`Tactical countdown: ${metrics.daysRemaining} rotations remaining.`);
  }

  const activePhrases = mode === 'bestie' ? bestiePhrases : classicPhrases;
  const currentMessage = activePhrases[speechIndex % activePhrases.length];

  const cycleMessage = () => {
    setSpeechIndex((prev) => prev + 1);
    sound.playBlip(500);
  };

  if (isMinimized) {
    return (
      <button
        onClick={() => {
          setIsMinimized(false);
          sound.playBlip(600);
        }}
        className={`fixed bottom-4 right-4 z-40 p-2.5 rounded-full border-3 shadow-xl flex items-center gap-2 cursor-pointer transition-all hover:scale-105 ${
          mode === 'bestie'
            ? 'bg-[#FFF4E8] border-[#A64D79] text-[#A64D79]'
            : 'bg-[#18243A] border-[#4A90E2] text-[#8DD9B5]'
        }`}
        title="Open Bestie Assistant"
      >
        <img
          src={theme.mascotImage}
          alt={theme.mascotName}
          referrerPolicy="no-referrer"
          className="w-8 h-8 rounded-full object-cover border border-inherit"
        />
        <span className="text-xs font-bold font-pixel pr-1 hidden sm:inline">
          {mode === 'bestie' ? 'CHAT BESTIE' : 'ASSISTANT'}
        </span>
      </button>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-40 max-w-sm w-[calc(100vw-2rem)] sm:w-80 animate-slideUp">
      <div
        className={`rounded-2xl border-3 ${theme.cardBg} ${theme.cardBorder} shadow-[6px_6px_0px_rgba(0,0,0,0.25)] overflow-hidden`}
      >
        {/* Title bar */}
        <div
          className={`px-3 py-1.5 flex items-center justify-between text-xs font-bold border-b ${
            mode === 'bestie'
              ? 'bg-[#F6D5E3] border-[#A64D79]/30 text-[#A64D79]'
              : 'bg-[#20324E] border-[#4A90E2]/40 text-[#8DD9B5]'
          }`}
        >
          <div className="flex items-center gap-1.5 font-pixel">
            <span>{mode === 'bestie' ? '💗' : '🤖'}</span>
            <span>{theme.mascotName}</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsMinimized(true)}
              className="p-0.5 rounded hover:opacity-75 cursor-pointer"
              title="Minimize"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mascot & Speech Body */}
        <div className="p-3 flex items-start gap-3">
          <img
            src={theme.mascotImage}
            alt={theme.mascotName}
            referrerPolicy="no-referrer"
            className="w-14 h-14 rounded-xl object-cover shrink-0 border-2 border-inherit shadow-sm"
          />

          <div className="flex-1 space-y-2">
            <div
              className={`p-2.5 rounded-xl border text-xs font-medium leading-relaxed relative ${
                mode === 'bestie'
                  ? 'bg-[#FFF9F3] border-[#A64D79]/20 text-[#541c38]'
                  : 'bg-[#131D2E] border-[#4A90E2]/30 text-slate-200'
              }`}
            >
              <p>"{currentMessage}"</p>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-[10px] opacity-60 font-mono">
                Allowance: ${(metrics.dailyAllowanceCents / 100).toFixed(2)}/day
              </span>

              <button
                onClick={cycleMessage}
                className={`text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 cursor-pointer transition-colors ${
                  mode === 'bestie'
                    ? 'bg-[#F6D5E3] text-[#A64D79] hover:bg-[#ebd0dd]'
                    : 'bg-[#20324E] text-[#8DD9B5] hover:bg-[#283e61]'
                }`}
              >
                <span>Next Tip</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
