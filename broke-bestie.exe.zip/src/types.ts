export type AppMode = 'bestie' | 'classic';

export type PayFrequency = 'weekly' | 'biweekly' | 'twice_monthly' | 'monthly' | 'custom';

export type PaymentMethod = 'bank' | 'cash';

export type TransactionType = 'income' | 'expense' | 'transfer_to_cash' | 'transfer_to_bank';

export interface Bill {
  id: string;
  name: string;
  amountCents: number; // stored in integer cents
  dueDate: string; // YYYY-MM-DD
  category: 'rent' | 'utilities' | 'phone' | 'subscription' | 'loan' | 'insurance' | 'other';
  isPaid: boolean;
}

export interface EssentialCategory {
  id: string;
  name: string;
  budgetedCents: number;
  spentCents: number; // spent so far in this period
  iconName: string;
}

export interface Transaction {
  id: string;
  description: string;
  amountCents: number;
  type: TransactionType;
  paymentMethod: PaymentMethod;
  date: string; // ISO date
  category?: string;
  essentialCategoryId?: string; // if tied to essential reserves
  isDeluluPurchase?: boolean;
}

export interface Achievement {
  id: string;
  titleBestie: string;
  titleClassic: string;
  descBestie: string;
  descClassic: string;
  iconBestie: string;
  iconClassic: string;
  unlocked: boolean;
  unlockedAt?: string;
}

export interface FinancialProfile {
  bankBalanceCents: number;
  cashBalanceCents: number;
  expectedPaycheckCents: number;
  payFrequency: PayFrequency;
  nextPaydayDate: string; // YYYY-MM-DD
  lastPaydayDate: string; // YYYY-MM-DD
  bills: Bill[];
  essentials: EssentialCategory[];
  transactions: Transaction[];
  savedItems: {
    id: string;
    name: string;
    amountCents: number;
    savedDate: string;
  }[];
}

export type HealthStatus = 'green' | 'yellow' | 'red';

export interface FinancialHealthMetrics {
  totalFundsCents: number;
  bankBalanceCents: number;
  cashBalanceCents: number;
  unpaidBillsCents: number;
  remainingEssentialsCents: number;
  reservedFundsCents: number;
  safeToSpendCents: number;
  daysRemaining: number;
  totalCycleDays: number;
  cycleDayNumber: number;
  dailyAllowanceCents: number;
  healthStatus: HealthStatus;
  healthScorePercent: number; // 0 to 100 for health bar
  shortfallCents: number; // 0 if safeToSpend >= 0, else positive shortfall
}
