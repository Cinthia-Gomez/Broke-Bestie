import React, { useState } from 'react';
import { GameProvider, useGame } from './context/GameContext';
import { Header } from './components/Header';
import { WelcomeScreen } from './components/WelcomeScreen';
import { SetupModal } from './components/SetupModal';
import { Dashboard } from './components/Dashboard';
import { TransactionsView } from './components/TransactionsView';
import { PurchaseChecker } from './components/PurchaseChecker';
import { GirlMathCalculator } from './components/GirlMathCalculator';
import { RescueBudgetView } from './components/RescueBudgetView';
import { AchievementsView } from './components/AchievementsView';
import { WarningModal } from './components/WarningModal';
import { AssistantWidget } from './components/AssistantWidget';
import { THEMES } from './utils/theme';

const MainApp: React.FC = () => {
  const {
    mode,
    hasCompletedSetup,
    activeTab,
    setActiveTab,
    showWarningModal,
    setShowWarningModal,
  } = useGame();

  const theme = THEMES[mode];
  const [isSetupOpen, setIsSetupOpen] = useState(false);
  const [initialTxType, setInitialTxType] = useState<'expense' | 'income' | 'transfer'>('expense');

  // If first time visit and setup not completed, show Welcome Screen
  if (!hasCompletedSetup) {
    return (
      <>
        <WelcomeScreen onStartSetup={() => setIsSetupOpen(true)} />
        <SetupModal isOpen={isSetupOpen} onClose={() => setIsSetupOpen(false)} />
      </>
    );
  }

  return (
    <div className={`min-h-screen ${theme.bgCanvas} transition-colors duration-200 flex flex-col font-sans selection:bg-[#A64D79] selection:text-white`}>
      {/* Top Navigation Bar */}
      <Header onOpenSetup={() => setIsSetupOpen(true)} />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 md:py-8">
        {activeTab === 'dashboard' && (
          <Dashboard
            onOpenSetup={() => setIsSetupOpen(true)}
            onOpenQuickTx={(t) => {
              setInitialTxType(t || 'expense');
              setActiveTab('transactions');
            }}
          />
        )}

        {activeTab === 'transactions' && (
          <TransactionsView initialType={initialTxType} />
        )}

        {activeTab === 'purchase_checker' && <PurchaseChecker />}

        {activeTab === 'girl_math' && <GirlMathCalculator />}

        {activeTab === 'rescue' && <RescueBudgetView />}

        {activeTab === 'achievements' && <AchievementsView />}
      </main>

      {/* Retro Footer */}
      <footer className={`mt-auto border-t py-6 text-xs text-center transition-colors ${
        mode === 'bestie'
          ? 'border-[#A64D79]/20 text-[#A64D79]/80 bg-[#FFF4E8]'
          : 'border-[#4A90E2]/30 text-slate-400 bg-[#0E1726]'
      }`}>
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-pixel font-bold">BROKE_BESTIE.EXE</span>
            <span>·</span>
            <span>Payday Survival Game</span>
            <span>·</span>
            <span>Integer Cents Safe-to-Spend Engine</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Mode: {mode === 'bestie' ? 'Bestie Mode 💗' : 'Classic Mode 🎮'}</span>
            <span>·</span>
            <span>No external bank logins required</span>
            <span>·</span>
            <span>Local data storage</span>
          </div>
        </div>
      </footer>

      {/* Floating Retro Assistant Widget */}
      <AssistantWidget />

      {/* Setup Modal */}
      <SetupModal isOpen={isSetupOpen} onClose={() => setIsSetupOpen(false)} />

      {/* Low Funds Dramatic Warning Modal */}
      <WarningModal
        isOpen={showWarningModal}
        onClose={() => setShowWarningModal(false)}
        onOpenRescue={() => {
          setShowWarningModal(false);
          setActiveTab('rescue');
        }}
        onOpenExpenses={() => {
          setShowWarningModal(false);
          setActiveTab('transactions');
        }}
      />
    </div>
  );
};

export default function App() {
  return (
    <GameProvider>
      <MainApp />
    </GameProvider>
  );
}
