import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  AppMode,
  FinancialProfile,
  FinancialHealthMetrics,
  Transaction,
  Bill,
  Achievement,
} from '../types';
import {
  calculateHealthMetrics,
  getDemoFinancialProfile,
  getInitialFinancialProfile,
} from '../utils/finance';
import { INITIAL_ACHIEVEMENTS } from '../utils/achievements';
import { sound } from '../utils/audio';

interface GameContextType {
  mode: AppMode;
  setMode: (mode: AppMode) => void;
  hasCompletedSetup: boolean;
  setHasCompletedSetup: (val: boolean) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  profile: FinancialProfile;
  metrics: FinancialHealthMetrics;
  achievements: Achievement[];
  showWarningModal: boolean;
  setShowWarningModal: (val: boolean) => void;
  isMuted: boolean;
  toggleMute: () => void;
  loadDemoData: () => void;
  resetAllData: () => void;
  updateProfile: (updater: (prev: FinancialProfile) => FinancialProfile) => void;
  addTransaction: (tx: Omit<Transaction, 'id'>) => { success: boolean; error?: string };
  deleteTransaction: (id: string) => void;
  toggleBillPaid: (id: string) => void;
  addBill: (bill: Omit<Bill, 'id'>) => void;
  deleteBill: (id: string) => void;
  saveItemForLater: (name: string, amountCents: number) => void;
  removeSavedItem: (id: string) => void;
  unlockAchievement: (id: string) => void;
}

const STORAGE_KEY_PROFILE = 'broke_bestie_profile_v1';
const STORAGE_KEY_MODE = 'broke_bestie_mode_v1';
const STORAGE_KEY_SETUP = 'broke_bestie_setup_v1';
const STORAGE_KEY_ACHIEVEMENTS = 'broke_bestie_achievements_v1';

const GameContext = createContext<GameContextType | undefined>(undefined);

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load mode
  const [mode, setModeState] = useState<AppMode>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_MODE);
    return saved === 'classic' ? 'classic' : 'bestie';
  });

  // Setup completion state
  const [hasCompletedSetup, setHasCompletedSetupState] = useState<boolean>(() => {
    return localStorage.getItem(STORAGE_KEY_SETUP) === 'true';
  });

  const [activeTab, setActiveTabState] = useState<string>('dashboard');
  const [isMuted, setIsMuted] = useState<boolean>(sound.isMuted);

  // Profile data
  const [profile, setProfile] = useState<FinancialProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PROFILE);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return getInitialFinancialProfile();
  });

  // Achievements
  const [achievements, setAchievements] = useState<Achievement[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ACHIEVEMENTS);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return INITIAL_ACHIEVEMENTS;
  });

  const [showWarningModal, setShowWarningModal] = useState<boolean>(false);
  const [prevHealthStatus, setPrevHealthStatus] = useState<'green' | 'yellow' | 'red'>('green');

  // Compute live metrics
  const metrics = useMemo(() => {
    return calculateHealthMetrics(profile);
  }, [profile]);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PROFILE, JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_MODE, mode);
  }, [mode]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_SETUP, String(hasCompletedSetup));
  }, [hasCompletedSetup]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ACHIEVEMENTS, JSON.stringify(achievements));
  }, [achievements]);

  // Monitor status transition to Red to trigger retro alarm popup
  useEffect(() => {
    if (metrics.healthStatus === 'red' && prevHealthStatus !== 'red' && hasCompletedSetup) {
      setShowWarningModal(true);
      sound.playAlert();
    }
    setPrevHealthStatus(metrics.healthStatus);
  }, [metrics.healthStatus, prevHealthStatus, hasCompletedSetup]);

  const unlockAchievement = useCallback((id: string) => {
    setAchievements((prev) =>
      prev.map((a) => {
        if (a.id === id && !a.unlocked) {
          sound.playLevelUp();
          return { ...a, unlocked: true, unlockedAt: new Date().toISOString() };
        }
        return a;
      })
    );
  }, []);

  const setMode = useCallback((newMode: AppMode) => {
    setModeState(newMode);
    sound.playBlip(680);
  }, []);

  const setActiveTab = useCallback((tab: string) => {
    setActiveTabState(tab);
    sound.playBlip(480);
  }, []);

  const toggleMute = useCallback(() => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
    if (!muted) sound.playBlip(600);
  }, []);

  const setHasCompletedSetup = useCallback((val: boolean) => {
    setHasCompletedSetupState(val);
  }, []);

  const updateProfile = useCallback((updater: (prev: FinancialProfile) => FinancialProfile) => {
    setProfile(updater);
  }, []);

  const loadDemoData = useCallback(() => {
    const demo = getDemoFinancialProfile();
    setProfile(demo);
    setHasCompletedSetupState(true);
    sound.playCash();
    unlockAchievement('wallet_tactician');
  }, [unlockAchievement]);

  const resetAllData = useCallback(() => {
    const fresh = getInitialFinancialProfile();
    setProfile(fresh);
    setHasCompletedSetupState(false);
    setActiveTabState('dashboard');
    localStorage.removeItem(STORAGE_KEY_PROFILE);
    localStorage.removeItem(STORAGE_KEY_SETUP);
    sound.playBlip(320);
  }, []);

  // Financial transactions engine with integer cents & dual-wallet validation
  const addTransaction = useCallback(
    (txData: Omit<Transaction, 'id'>): { success: boolean; error?: string } => {
      const { amountCents, paymentMethod, type, essentialCategoryId } = txData;

      if (amountCents <= 0) {
        return { success: false, error: 'Amount must be greater than $0.00' };
      }

      // 1. CASH WITHDRAWAL (Transfer from Bank to Cash)
      if (type === 'transfer_to_cash') {
        if (profile.bankBalanceCents < amountCents) {
          return {
            success: false,
            error: `Insufficient bank funds! You have $${(profile.bankBalanceCents / 100).toFixed(2)} in your bank, but tried to withdraw $${(amountCents / 100).toFixed(2)}.`,
          };
        }
        const newTx: Transaction = {
          ...txData,
          id: 'tx-' + Date.now(),
        };
        setProfile((prev) => ({
          ...prev,
          bankBalanceCents: prev.bankBalanceCents - amountCents,
          cashBalanceCents: prev.cashBalanceCents + amountCents,
          transactions: [newTx, ...prev.transactions],
        }));
        sound.playCash();
        unlockAchievement('cash_tracker');
        return { success: true };
      }

      // 2. CASH DEPOSIT (Transfer from Cash to Bank)
      if (type === 'transfer_to_bank') {
        if (profile.cashBalanceCents < amountCents) {
          return {
            success: false,
            error: `Insufficient physical cash! You only have $${(profile.cashBalanceCents / 100).toFixed(2)} cash in hand.`,
          };
        }
        const newTx: Transaction = {
          ...txData,
          id: 'tx-' + Date.now(),
        };
        setProfile((prev) => ({
          ...prev,
          cashBalanceCents: prev.cashBalanceCents - amountCents,
          bankBalanceCents: prev.bankBalanceCents + amountCents,
          transactions: [newTx, ...prev.transactions],
        }));
        sound.playCash();
        unlockAchievement('cash_tracker');
        return { success: true };
      }

      // 3. INCOME DEPOSIT
      if (type === 'income') {
        const newTx: Transaction = {
          ...txData,
          id: 'tx-' + Date.now(),
        };
        setProfile((prev) => {
          const next = { ...prev };
          if (paymentMethod === 'cash') {
            next.cashBalanceCents += amountCents;
          } else {
            next.bankBalanceCents += amountCents;
          }
          next.transactions = [newTx, ...next.transactions];
          return next;
        });
        sound.playCash();
        return { success: true };
      }

      // 4. EXPENSE (Card or Cash)
      if (type === 'expense') {
        if (paymentMethod === 'cash' && profile.cashBalanceCents < amountCents) {
          return {
            success: false,
            error: `Not enough physical cash! You have $${(profile.cashBalanceCents / 100).toFixed(2)} in your cash wallet. Withdraw cash from your bank first!`,
          };
        }
        if (paymentMethod === 'bank' && profile.bankBalanceCents < amountCents) {
          return {
            success: false,
            error: `Overdraft alert! Bank balance is $${(profile.bankBalanceCents / 100).toFixed(2)}, but purchase is $${(amountCents / 100).toFixed(2)}.`,
          };
        }

        const newTx: Transaction = {
          ...txData,
          id: 'tx-' + Date.now(),
        };

        setProfile((prev) => {
          const next = { ...prev };
          if (paymentMethod === 'cash') {
            next.cashBalanceCents -= amountCents;
          } else {
            next.bankBalanceCents -= amountCents;
          }
          // If attributed to essential reserve category, mark spent in that category
          if (essentialCategoryId) {
            next.essentials = next.essentials.map((cat) => {
              if (cat.id === essentialCategoryId) {
                return { ...cat, spentCents: cat.spentCents + amountCents };
              }
              return cat;
            });
          }
          next.transactions = [newTx, ...next.transactions];
          return next;
        });

        sound.playBlip(380);
        return { success: true };
      }

      return { success: false, error: 'Unknown transaction type' };
    },
    [profile, unlockAchievement]
  );

  const deleteTransaction = useCallback((id: string) => {
    setProfile((prev) => {
      const tx = prev.transactions.find((t) => t.id === id);
      if (!tx) return prev;

      const next = { ...prev };
      // Revert balances
      if (tx.type === 'expense') {
        if (tx.paymentMethod === 'cash') {
          next.cashBalanceCents += tx.amountCents;
        } else {
          next.bankBalanceCents += tx.amountCents;
        }
        if (tx.essentialCategoryId) {
          next.essentials = next.essentials.map((cat) => {
            if (cat.id === tx.essentialCategoryId) {
              return { ...cat, spentCents: Math.max(0, cat.spentCents - tx.amountCents) };
            }
            return cat;
          });
        }
      } else if (tx.type === 'income') {
        if (tx.paymentMethod === 'cash') {
          next.cashBalanceCents = Math.max(0, next.cashBalanceCents - tx.amountCents);
        } else {
          next.bankBalanceCents = Math.max(0, next.bankBalanceCents - tx.amountCents);
        }
      } else if (tx.type === 'transfer_to_cash') {
        next.bankBalanceCents += tx.amountCents;
        next.cashBalanceCents = Math.max(0, next.cashBalanceCents - tx.amountCents);
      } else if (tx.type === 'transfer_to_bank') {
        next.cashBalanceCents += tx.amountCents;
        next.bankBalanceCents = Math.max(0, next.bankBalanceCents - tx.amountCents);
      }

      next.transactions = next.transactions.filter((t) => t.id !== id);
      return next;
    });
    sound.playBlip(300);
  }, []);

  const toggleBillPaid = useCallback((id: string) => {
    setProfile((prev) => {
      const nextBills = prev.bills.map((b) => {
        if (b.id === id) {
          return { ...b, isPaid: !b.isPaid };
        }
        return b;
      });
      // check if all bills are now paid
      const allPaid = nextBills.length > 0 && nextBills.every((b) => b.isPaid);
      if (allPaid) {
        unlockAchievement('bill_boss');
      }
      return { ...prev, bills: nextBills };
    });
    sound.playBlip(700);
  }, [unlockAchievement]);

  const addBill = useCallback((billData: Omit<Bill, 'id'>) => {
    const newBill: Bill = {
      ...billData,
      id: 'bill-' + Date.now(),
    };
    setProfile((prev) => ({
      ...prev,
      bills: [...prev.bills, newBill],
    }));
    sound.playBlip(550);
  }, []);

  const deleteBill = useCallback((id: string) => {
    setProfile((prev) => ({
      ...prev,
      bills: prev.bills.filter((b) => b.id !== id),
    }));
    sound.playBlip(320);
  }, []);

  const saveItemForLater = useCallback((name: string, amountCents: number) => {
    setProfile((prev) => ({
      ...prev,
      savedItems: [
        {
          id: 'wish-' + Date.now(),
          name,
          amountCents,
          savedDate: new Date().toISOString(),
        },
        ...prev.savedItems,
      ],
    }));
    sound.playGirlMathSparkle();
    unlockAchievement('delulu_dodger');
  }, [unlockAchievement]);

  const removeSavedItem = useCallback((id: string) => {
    setProfile((prev) => ({
      ...prev,
      savedItems: prev.savedItems.filter((i) => i.id !== id),
    }));
  }, []);

  return (
    <GameContext.Provider
      value={{
        mode,
        setMode,
        hasCompletedSetup,
        setHasCompletedSetup,
        activeTab,
        setActiveTab,
        profile,
        metrics,
        achievements,
        showWarningModal,
        setShowWarningModal,
        isMuted,
        toggleMute,
        loadDemoData,
        resetAllData,
        updateProfile,
        addTransaction,
        deleteTransaction,
        toggleBillPaid,
        addBill,
        deleteBill,
        saveItemForLater,
        removeSavedItem,
        unlockAchievement,
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};
